import os
import time
import subprocess
import re
import json
import pandas as pd
from datetime import datetime
from google.cloud import storage

# ==========================================
# --- CONFIGURAÇÕES DE AMBIENTE ---
# ==========================================
# 1. Google Cloud (Coloque o seu JSON de chave na mesma pasta)
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "google_key.json"
BUCKET_NAME = "cerebro-sardinha-dados" # Nome exato do seu bucket

# 2. YouTube Canal
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'

# 3. Arquivos de Banco de Dados
DB_FILE = 'base_conhecimento_auvp.csv'
EXCEL_FILE = 'base_conhecimento_auvp.xlsx'
OUTPUT_FOLDER = 'cerebro_auvp_playlists'

# 4. Dicionário de Correção Fonética (O Raul fala, o YouTube entende errado)
DICIONARIO_RAUL = {
    "Renode": "Hinode", "Renodê": "Hinode", "Rino": "Hinode",
    "Selyc": "Selic", "b tg": "BTG Pactual", "au vp": "AUVP",
    "diagrama do cerrado": "Diagrama do Cerrado", "investidor sardinha": "Investidor Sardinha"
}

# ==========================================
# --- FUNÇÕES DE APOIO ---
# ==========================================

def sanitizar_nome_arquivo(nome):
    """Remove caracteres que o Windows proíbe em nomes de arquivos"""
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    """Converte YYYYMMDD para DD/MM/YYYY"""
    if not data_str or data_str == 'NA': return "01/01/2000"
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_texto_profundo(texto):
    """Limpeza para deixar o texto perfeito para o RAG/NotebookLM"""
    texto = re.sub(r'Kind: captions Language: \w+', '', texto)
    texto = re.sub(r'\[.*?\]', '', texto) # Remove [música], [risos]
    texto = texto.replace("&gt;", ">").replace("&lt;", "<").replace("&nbsp;", " ")
    for erro, correcao in DICIONARIO_RAUL.items():
        texto = re.sub(erro, correcao, texto, flags=re.IGNORECASE)
    texto = re.sub(r'\s+', ' ', texto) # Remove espaços duplos
    return texto.strip()

def limpar_vtt(caminho_vtt):
    """Lê o arquivo VTT e remove repetições de fala e metadados"""
    if not os.path.exists(caminho_vtt): return ""
    try:
        with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
            linhas = f.readlines()
        texto_puro = []
        for l in linhas:
            if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l:
                l_limpa = re.sub(r'<[^>]*>', '', l).strip()
                if l_limpa: texto_puro.append(l_limpa)
        
        # Remove repetições consecutivas de palavras (bug comum de legenda automática)
        bruto = " ".join(texto_puro).split()
        res = []
        if bruto:
            res.append(bruto[0])
            for i in range(1, len(bruto)):
                if bruto[i].lower() != bruto[i-1].lower(): res.append(bruto[i])
        return limpar_texto_profundo(" ".join(res))
    except: return ""

def upload_cloud(arquivo_local, nome_nuvem):
    """Faz o upload do arquivo para o Google Cloud Storage"""
    try:
        client = storage.Client()
        bucket = client.bucket(BUCKET_NAME)
        blob = bucket.blob(f"conhecimento/{nome_nuvem}")
        blob.upload_from_filename(arquivo_local)
        return True
    except Exception as e:
        print(f"      ☁️ Erro Cloud: {e}")
        return False

def executar_comando(cmd):
    """Executa yt-dlp de forma protegida contra erros de encoding no Windows"""
    try:
        result = subprocess.run(cmd, capture_output=True, text=False)
        return result.stdout.decode('utf-8', errors='replace')
    except: return ""

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_engine_v11():
    print("\n" + "█"*60)
    print("🚀 SARDINHA ENGINE V11: THE GOD MODE (Full Sync + Clean)")
    print("█"*60 + "\n")

    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)
    
    # Carregar Banco de Dados (CSV)
    if os.path.exists(DB_FILE):
        df_db = pd.read_csv(DB_FILE, dtype=str)
    else:
        df_db = pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    # 1. Mapeamento Total do Canal
    print("📡 Mapeando playlists do canal...")
    stdout_p = executar_comando(['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL])
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines):
            playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    print(f"✅ {len(playlists_info)} Playlists encontradas. Cruzando vídeos...")

    # 2. Extração de Metadados detalhados
    all_videos = []
    for p in playlists_info:
        print(f"   📂 Escaneando: {p['title'][:40]}...")
        stdout_v = executar_comando(['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', f"https://www.youtube.com/playlist?list={p['id']}"])
        for line in stdout_v.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_videos.append({'id': parts[0], 'date': formatar_data(parts[1]), 'views': parts[2], 'title': parts[3], 'playlist': p['title']})

    total_canal = len(all_videos)
    print(f"\n📊 Total de {total_canal} vídeos identificados.")
    print("-" * 60)

    # 3. Mineração de Texto e Sincronização Cloud
    sucessos = 0
    pulos = 0

    for idx, video in enumerate(all_videos, 1):
        v_id, v_title, v_link = video['id'], video['title'], f"https://www.youtube.com/watch?v={video['id']}"
        v_playlist_limpa = sanitizar_nome_arquivo(video['playlist'])
        caminho_local_txt = os.path.join(OUTPUT_FOLDER, f"{v_playlist_limpa}.txt")
        prefix = f"[{idx}/{total_canal}]"

        # Pular se já estiver no CSV como Sucesso
        if v_id in df_db['ID'].values:
            status = df_db.loc[df_db['ID'] == v_id, 'Status'].values[0]
            if status == 'Sucesso':
                print(f"{prefix} ⏭️  Pular: {v_title[:45]}...")
                pulos += 1
                continue

        print(f"{prefix} 🎬 Extraindo: {v_title[:45]}...")
        
        try:
            temp_out = f"temp_{v_id}"
            # Extração da legenda via yt-dlp
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            vtt_file = f"{temp_out}.pt.vtt"
            if os.path.exists(vtt_file):
                texto = limpar_vtt(vtt_file)
                if len(texto) > 150:
                    # Grava no TXT Local
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\n{'='*60}\nTITULO: {v_title}\nDATA: {video['date']}\nVIEWS: {video['views']}\nLINK: {v_link}\n{'-'*60}\nCONTEÚDO:\n{texto}\n{'='*60}\n")
                    
                    # Sincroniza com Google Cloud Storage
                    upload_cloud(caminho_local_txt, f"{v_playlist_limpa}.txt")

                    # Atualiza Banco CSV
                    nova_linha = {
                        'ID': v_id, 'Data_Pub': video['date'], 'Link': v_link, 
                        'Titulo': v_title, 'Playlist': video['playlist'], 
                        'Views': video['views'], 'Status': 'Sucesso'
                    }
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8')
                    sucessos += 1
                    print(f"      ✅ Sucesso Total!")
                
                if os.path.exists(vtt_file): os.remove(vtt_file)
            else:
                print(f"      ❌ YouTube sem transcrição.")
            
            time.sleep(3) # Pausa amigável

        except Exception as e:
            print(f"      ❌ Erro: {e}")

    # 4. Geração do Excel Final
    print("\n📊 Gerando Excel Analítico...")
    try:
        df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
        df_db.to_excel(EXCEL_FILE, index=False)
    except: print("⚠️ Erro ao gerar Excel. Arquivo pode estar aberto.")

    print("\n" + "█"*60)
    print(f"🏆 OPERAÇÃO FINALIZADA!")
    print(f"📂 Arquivos minerados: {sucessos}")
    print(f"📄 Excel Analítico: {EXCEL_FILE}")
    print(f"☁️ Cloud Bucket: {BUCKET_NAME}")
    print("█"*60)

if __name__ == "__main__":
    sardinha_engine_v11()