import os
import time
import subprocess
import re
import io
import pandas as pd
from datetime import datetime
from fpdf import FPDF
from fpdf.enums import XPos, YPos

# Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload

# ==========================================
# --- CONFIGURAÇÕES ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

CANAL_URL = 'https://www.youtube.com/@InvestidorSardinha'

# Hierarquia de Varredura (Garante que Vídeos Gerais sejam os últimos)
ABAS_VARRER = [
    {"tipo": "Curso", "url": f"{CANAL_URL}/courses"},
    {"tipo": "Playlist", "url": f"{CANAL_URL}/playlists"},
    {"tipo": "Short", "url": f"{CANAL_URL}/shorts"},
    {"tipo": "Podcast", "url": f"{CANAL_URL}/podcasts"},
    {"tipo": "Stream", "url": f"{CANAL_URL}/streams"},
    {"tipo": "Video_Geral", "url": f"{CANAL_URL}/videos"} 
]

LOCAL_BRAIN = 'cerebro_local'
LOCAL_GESTAO = 'gestao_local'
DB_FILE = os.path.join(LOCAL_GESTAO, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(LOCAL_GESTAO, 'base_conhecimento_auvp.xlsx')
MAX_WORDS = 400000 

# ==========================================
# --- MOTOR ANTI-LIXO (VTT) ---
# ==========================================

def limpar_vtt_definitivo(caminho_vtt):
    """Remove o efeito rolling/scroll das legendas automáticas do YouTube"""
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    
    frases_unicas = []
    ultima_frase = ""
    
    for linha in linhas:
        # Pula marcações de tempo e cabeçalho
        if '-->' in linha or 'WEBVTT' in linha or re.match(r'^\d+$', linha.strip()):
            continue
            
        # Remove tags de formatação embutidas pelo YT (<c>, <00:00:00>, etc)
        texto = re.sub(r'<[^>]*>', '', linha).strip()
        
        if texto and texto != ultima_frase:
            # Lógica Anti-Rolling: Se a linha nova é continuação da anterior (scroll)
            if ultima_frase and texto.startswith(ultima_frase):
                frases_unicas.pop() # Remove a versão incompleta
            
            frases_unicas.append(texto)
            ultima_frase = texto
            
    return " ".join(frases_unicas)

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    if not nome or nome == 'NA': return "Geral"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str == 'NA': return "01/01/2000"
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return str(data_str)

def sanitizar_texto_pdf(texto):
    return "".join(c for c in texto if c.isprintable() or c == '\n')

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- PDF DESIGNER ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('helvetica', 'B', 14)
        self.set_text_color(255, 140, 0)
        self.cell(0, 10, 'CONHECIMENTO AUVP', 0, align='C', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font('helvetica', 'I', 8)
        self.set_text_color(128, 128, 128)
        self.cell(0, 10, f'Página {self.page_no()}', 0, 0, 'C')

def gerar_pdf_in_memory(blocos):
    pdf = AUVP_PDF()
    pdf.set_margins(15, 15, 15)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    largura = pdf.epw
    
    for bloco in blocos:
        texto = sanitizar_texto_pdf(bloco)
        try: msg = texto.encode('latin-1', 'replace').decode('latin-1')
        except: msg = texto.encode('ascii', 'replace').decode('ascii')
        
        if "TITULO:" in msg:
            pdf.ln(5)
            pdf.set_font('helvetica', 'B', 12)
            pdf.set_text_color(0, 0, 0)
            pdf.multi_cell(largura, 7, msg, border='B', align='L')
            pdf.ln(2)
        elif any(tag in msg for tag in ["LINK:", "DATA:", "VIEWS:", "TIPO:", "NOME:"]):
            pdf.set_font('helvetica', 'I', 9)
            pdf.set_text_color(100, 100, 100)
            pdf.multi_cell(largura, 5, msg, align='L')
        else:
            pdf.set_font('helvetica', size=10)
            pdf.set_text_color(40, 40, 40)
            pdf.multi_cell(largura, 6, msg, align='L')
            pdf.ln(3)
    return pdf.output()

# ==========================================
# --- DRIVE SYNC ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token: creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def enviar_lote_drive(service, nome, blocos):
    print(f"   ⬆️ Subindo PDF: {nome}...")
    pdf_bytes = gerar_pdf_in_memory(blocos)
    media = MediaIoBaseUpload(io.BytesIO(pdf_bytes), mimetype='application/pdf', resumable=True)
    q = f"name = '{nome}' and '{FOLDER_BRAIN_DRIVE}' in parents and trashed = false"
    res = service.files().list(q=q).execute().get('files', [])
    if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
    else: service.files().create(body={'name': nome, 'parents': [FOLDER_BRAIN_DRIVE]}, media_body=media).execute()

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_engine_definitivo():
    print("\n" + "█"*80)
    print("🚀 SARDINHA ENGINE: THE DEFINITIVE ARCHITECT")
    print("█"*80 + "\n")
    
    if not os.path.exists(LOCAL_BRAIN): os.makedirs(LOCAL_BRAIN)
    if not os.path.exists(LOCAL_GESTAO): os.makedirs(LOCAL_GESTAO)

    # Memória Global para garantir Exigência 4 e 5
    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data', 'Link', 'Titulo', 'Tipo', 'Nome', 'Views', 'Status'])
    ids_processados = set(df_db['ID'].tolist()) if not df_db.empty else set()
    
    # 1. MAPEAMENTO HIERÁRQUICO
    manifesto_extracao = []
    
    for aba in ABAS_VARRER:
        tipo = aba['tipo']
        print(f"📡 Mapeando {tipo}... ", end="", flush=True)
        
        # O %(playlist_title)s captura o nome da playlist, se existir
        cmd = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s|||%(playlist_title)s', aba['url']]
        raw = executar_comando(cmd)
        listagem = [line for line in raw.split('\n') if '|||' in line]
        
        count_novos = 0
        for line in listagem:
            parts = line.split('|||')
            v_id = parts[0]
            
            # Exigência 4: Só coleta se não estiver nos IDs já processados
            if v_id not in ids_processados:
                v_nome_agrupamento = sanitizar_nome(parts[4]) if len(parts) > 4 else tipo
                
                manifesto_extracao.append({
                    'ID': v_id, 'Data': formatar_data(parts[1]), 'Views': parts[2],
                    'Titulo': parts[3].strip(), 'Nome': v_nome_agrupamento,
                    'Tipo': tipo, 'Link': f"https://www.youtube.com/watch?v={v_id}", 'Status': 'Pendente'
                })
                ids_processados.add(v_id)
                count_novos += 1
                
        print(f"{count_novos} vídeos novos encontrados.")
        
        # Opcional: Imprimir títulos mapeados (feedback)
        novos_desta_aba = [v['Titulo'] for v in manifesto_extracao if v['Tipo'] == tipo]
        if novos_desta_aba:
            print(f"   ↳ Primeiros encontrados: {', '.join([t[:30]+'...' for t in novos_desta_aba[:3]])}")

    total_trabalho = len(manifesto_extracao)
    if total_trabalho == 0:
        print("\n✅ Nenhum vídeo novo para extrair. Partindo para Sincronização.")
    else:
        print(f"\n🎬 Iniciando Extração Local de {total_trabalho} vídeos...")

    # 2. MINERAÇÃO LOCAL
    for idx, video in enumerate(manifesto_extracao, 1):
        v_id, v_title, v_link, v_nome = video['ID'], video['Titulo'], video['Link'], video['Nome']
        caminho_local_txt = os.path.join(LOCAL_BRAIN, f"Base_{v_nome}.txt")
        prefix = f"[{idx}/{total_trabalho}] [{video['Tipo']}]"

        if v_title in ['[Private video]', '[Deleted video]']: continue

        # Exigência 6: Verifica fisicamente se o TXT já contém o link
        ja_no_txt = False
        if os.path.exists(caminho_local_txt):
            with open(caminho_local_txt, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if v_link in f.read(): ja_no_txt = True

        if ja_no_txt:
            print(f"{prefix} ⏭️  Pular: {v_title[:40]} (Já no TXT)")
            continue

        print(f"{prefix} 🎬 Extraindo transcrição: {v_title[:40]}...")
        try:
            temp_out = f"temp_{v_id}"
            # Força extração APENAS da legenda automática do YouTube em pt
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt.*', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            vtt = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            
            if vtt:
                texto = limpar_vtt_definitivo(vtt[0])
                if len(texto) > 100:
                    # Salva no TXT
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\nTITULO: {v_title}\nDATA: {video['Data']}\nVIEWS: {video['Views']}\nLINK: {v_link}\nTIPO: {video['Tipo']}\nNOME: {v_nome}\nCONTEÚDO:\n{texto}\n" + "="*50 + "\n")
                    
                    # Atualiza Planilha Local
                    video['Status'] = 'Sucesso'
                    df_db = pd.concat([df_db, pd.DataFrame([video])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                    print(f"      ✅ Sucesso! Transcrição salva e limpa.")
                else:
                    print(f"      ⚠️ Transcrição muito curta (provável erro do YT).")
                os.remove(vtt[0])
            else:
                print(f"      ❌ Sem transcrição automática disponível.")
            time.sleep(1.5)
        except Exception as e: print(f"      ❌ Erro Crítico: {e}")

    # 3. VERIFICAÇÃO FINAL E SINCRONIA CLOUD (Exigência 7 e 8)
    print("\n📊 Conferindo planilhas e empacotando PDFs para o Google Drive...")
    
    # Arruma planilhas
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    
    service = get_drive_service()
    
    # Processa os arquivos locais em TXT e transforma em PDF particionado
    for arq_txt in os.listdir(LOCAL_BRAIN):
        if arq_txt.endswith(".txt"):
            nome_base = arq_txt.replace(".txt", "")
            caminho_txt = os.path.join(LOCAL_BRAIN, arq_txt)
            
            with open(caminho_txt, 'r', encoding='utf-8-sig', errors='replace') as f:
                videos_lote = f.read().split("="*50)
            
            lote_pdf = []; words = 0; parte = 1
            for v_txt in videos_lote:
                if not v_txt.strip(): continue
                w_count = len(v_txt.split())
                
                # Quebra se o bloco de vídeos ultrapassar o limite seguro
                if words + w_count > MAX_WORDS:
                    enviar_lote_drive(service, f"{nome_base}_Parte_{parte}.pdf", lote_pdf)
                    lote_pdf = [v_txt]; words = w_count; parte += 1
                else:
                    lote_pdf.append(v_txt + "\n" + "="*50)
                    words += w_count
                    
            if lote_pdf:
                nome_final = f"{nome_base}_Parte_{parte}.pdf" if parte > 1 else f"{nome_base}.pdf"
                enviar_lote_drive(service, nome_final, lote_pdf)

    # Sobes as planilhas
    print("   ⬆️ Subindo Base de Dados (CSV e XLSX)...")
    csv_bytes = df_db.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig')
    media_csv = MediaIoBaseUpload(io.BytesIO(csv_bytes), mimetype='text/csv', resumable=True)
    
    q_csv = f"name = 'base_conhecimento_auvp.csv' and '{FOLDER_SHEETS_DRIVE}' in parents and trashed = false"
    res_csv = service.files().list(q=q_csv).execute().get('files', [])
    if res_csv: service.files().update(fileId=res_csv[0]['id'], media_body=media_csv).execute()
    else: service.files().create(body={'name': 'base_conhecimento_auvp.csv', 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media_csv).execute()

    with open(EXCEL_FILE, 'rb') as f:
        media_xls = MediaIoBaseUpload(io.BytesIO(f.read()), mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', resumable=True)
        q_xls = f"name = 'base_conhecimento_auvp.xlsx' and '{FOLDER_SHEETS_DRIVE}' in parents and trashed = false"
        res_xls = service.files().list(q=q_xls).execute().get('files', [])
        if res_xls: service.files().update(fileId=res_xls[0]['id'], media_body=media_xls).execute()
        else: service.files().create(body={'name': 'base_conhecimento_auvp.xlsx', 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media_xls).execute()

    print(f"\n🏆 PROCESSO TOTAL CONCLUÍDO! Ecossistema $ardinh'IA Atualizado e Limpo.")

if __name__ == "__main__":
    sardinha_engine_definitivo()