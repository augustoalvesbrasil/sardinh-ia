import pandas as pd
import subprocess
import os
from datetime import datetime
import time

# --- CONFIGURAÇÕES ---
DB_FILE = 'base_conhecimento_auvp.csv'
EXCEL_FILE = 'base_conhecimento_auvp.xlsx'

def formatar_data(data_str):
    if not data_str or str(data_str).strip() in ['NA', 'nan', 'None', '']: return ""
    try:
        # Tenta converter de YYYYMMDD para DD/MM/YYYY
        return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except:
        return str(data_str)

def pegar_metadados_avulso(v_link):
    """Busca apenas data e views de um link específico de forma rápida"""
    try:
        cmd = [
            'yt-dlp', '--skip-download', '--ignore-errors',
            '--print', '%(upload_date)s|||%(view_count)s',
            v_link
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')
        output = result.stdout.strip().split('|||')
        if len(output) >= 2:
            return formatar_data(output[0]), str(output[1])
    except:
        pass
    return "", "0"

def smart_metadata_patcher_v2():
    print("\n" + "="*50)
    print("🚀 SARDINHA SMART PATCHER V2: TIPO BLINDADO")
    print("="*50 + "\n")

    if not os.path.exists(DB_FILE):
        print(f"❌ Erro: O arquivo {DB_FILE} não existe.")
        return

    # 1. Carregar Banco FORÇANDO TUDO PARA STRING (Evita LossySetitemError)
    df = pd.read_csv(DB_FILE, dtype=str)
    
    # Garante que as colunas existam
    for col in ['Data_Pub', 'Views']:
        if col not in df.columns:
            df[col] = ""
        df[col] = df[col].fillna("").astype(str)

    # 2. Filtrar o que precisa de atualização
    # Considera vazio, NaN ou valor padrão de erro
    mask = (df['Data_Pub'].str.strip() == "") | (df['Data_Pub'] == "00/00/0000") | (df['Data_Pub'].isna())
    videos_para_atualizar = df[mask]
    
    total_pendentes = len(videos_para_atualizar)
    
    if total_pendentes == 0:
        print("✅ Tudo em dia! Todas as datas e views já estão preenchidas.")
        return

    print(f"📊 Encontrados {total_pendentes} vídeos pendentes.")
    print("-" * 30)

    # 3. Loop de Atualização
    contador = 0
    for idx, row in videos_para_atualizar.iterrows():
        v_link = row['Link']
        v_titulo = str(row['Titulo'])
        contador += 1
        
        print(f"[{contador}/{total_pendentes}] 🔎 {v_titulo[:40]}...")
        
        nova_data, novas_views = pegar_metadados_avulso(v_link)
        
        if nova_data:
            # Usando .loc para garantir que o Pandas aceite a atribuição
            df.loc[idx, 'Data_Pub'] = str(nova_data)
            df.loc[idx, 'Views'] = str(novas_views)
            
            # Salva o CSV a cada 5 vídeos para não sobrecarregar o disco
            if contador % 5 == 0:
                df.to_csv(DB_FILE, index=False, encoding='utf-8')
            
            print(f"      ✅ OK: {nova_data} | {novas_views} views")
        else:
            print(f"      ❌ Erro ao capturar.")
        
        time.sleep(1)

    # Salvamento final do CSV
    df.to_csv(DB_FILE, index=False, encoding='utf-8')

    # 4. Finalização Excel (Aqui voltamos a converter para número para ficar bonito)
    print("\n📊 Gerando Excel final...")
    try:
        # Cria uma cópia para o Excel com tipos numéricos
        df_excel = df.copy()
        df_excel['Views'] = pd.to_numeric(df_excel['Views'], errors='coerce').fillna(0).astype(int)
        df_excel.to_excel(EXCEL_FILE, index=False)
        print(f"✅ Excel salvo: {EXCEL_FILE}")
    except Exception as e:
        print(f"⚠️ Erro ao gerar Excel: {e}")

    print("\n" + "="*50)
    print("🏆 PROCESSO CONCLUÍDO!")
    print("="*50)

if __name__ == "__main__":
    smart_metadata_patcher_v2()