import os
import time
import subprocess
import re
import pandas as pd
from datetime import datetime

# Bibliotecas Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# ==========================================
# --- CONFIGURAÇÕES ---
# ==========================================
# IDs do Google Drive
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   # Pasta TXTs no Drive
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  # Pasta Planilhas no Drive

# Pastas Locais
LOCAL_BRAIN = 'cerebro_local'
LOCAL_DB = 'gestao_local'
DB_FILE = os.path.join(LOCAL_DB, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(LOCAL_DB, 'base_conhecimento_auvp.xlsx')

URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
SCOPES = ['https://www.googleapis.com/auth/drive']

# ==========================================
# --- CONEXÃO DRIVE ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

service = get_drive_service()

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str in ['NA', 'None']: return datetime.now().strftime('%d/%m/%Y')
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    texto = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l and 'Kind:' not in l]
    res = []
    if texto:
        res.append(texto[0])
        for i in range(1, len(texto)):
            if texto[i].lower() != texto[i-1].lower(): res.append(texto[i])
    return " ".join(res).strip()

def upload_ou_update(caminho_local, nome_drive, folder_id):
    """Sincroniza o arquivo local com o Drive (Cria ou Atualiza)"""
    query = f"name = '{nome_drive}' and '{folder_id}' in parents and trashed = false"
    results = service.files().list(q=query, fields="files(id)").execute()
    files = results.get('files', [])
    
    media = MediaFileUpload(caminho_local, resumable=True)
    if files:
        service.files().update(fileId=files[0]['id'], media_body=media).execute()
        return "Atualizado"
    else:
        file_metadata = {'name': nome_drive, 'parents': [folder_id]}
        service.files().create(body=file_metadata, media_body=media).execute()
        return "Criado"

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_hub_v16():
    print("\n" + "█"*70)
    print("🚀 SARDINHA HUB V16: ESTAÇÃO LOCAL -> GOOGLE DRIVE")
    print("█"*70 + "\n")

    for p in [LOCAL_BRAIN, LOCAL_DB]: 
        if not os.path.exists(p): os.makedirs(p)

    # 1. Carrega Banco Local
    if os.path.exists(DB_FILE):
        df_db = pd.read_csv(DB_FILE, dtype=str)
    else:
        df_db = pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    # 2. Mapeamento YouTube
    print("📡 Mapeando canal (Metadados completos)...")
    cmd_map = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(playlist_title)s|||%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', URL_CANAL]
    res = subprocess.run(cmd_map, capture_output=True, text=False)
    raw = res.stdout.decode('utf-8', errors='replace')
    
    all_videos = []
    for line in raw.split('\n'):
        parts = line.split('|||')
        if len(parts) >= 5:
            all_videos.append({'playlist': parts[0], 'id': parts[1], 'date': formatar_data(parts[2]), 'views': parts[3], 'title': parts[4]})

    total = len(all_videos)
    print(f"✅ {total} vídeos identificados.\n")

    # 3. Garimpo Local
    for idx, video in enumerate(all_videos, 1):
        v_id, v_title, v_link = video['id'], video['title'], f"https://www.youtube.com/watch?v={video['id']}"
        nome_txt = f"{sanitizar_nome(video['playlist'])}.txt"
        caminho_local_txt = os.path.join(LOCAL_BRAIN, nome_txt)
        prefix = f"[{idx}/{total}]"

        if v_title in ['[Private video]', '[Deleted video]']: continue

        # CHECK LOCAL: O vídeo já está no arquivo TXT do meu PC?
        ja_existe_local = False
        if os.path.exists(caminho_local_txt):
            with open(caminho_local_txt, 'r', encoding='utf-8-sig') as f:
                if v_link in f.read(): ja_existe_local = True

        if ja_existe_local:
            print(f"{prefix} ⏭️  Pular: {v_title[:45]} (OK)")
            continue

        print(f"{prefix} 🎬 Minerando: {v_title[:45]}...")
        
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt.*', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            # Busca qualquer arquivo de legenda baixado
            legendas = [f for f in os.listdir('.') if f.startswith(temp_out) and (f.endswith('.vtt') or f.endswith('.srt'))]
            
            if legendas:
                texto = limpar_vtt(legendas[0])
                if len(texto) > 150:
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\n{'='*70}\nTITULO: {v_title}\nDATA: {video['date']}\nVIEWS: {video['views']}\nLINK: {v_link}\n{'-'*70}\nCONTEÚDO:\n{texto}\n{'='*70}\n")
                    
                    # Atualiza Banco
                    nova_linha = {'ID': v_id, 'Data_Pub': video['date'], 'Link': v_link, 'Titulo': v_title, 'Playlist': video['playlist'], 'Views': video['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8')
                    print(f"      ✅ Extraído com sucesso!")
                
                for l in legendas: os.remove(l)
            else:
                print(f"      ❌ YouTube não liberou transcrição.")
            
            time.sleep(3) # Pausa estratégica

        except Exception as e:
            print(f"      ❌ Erro: {e}")

    # 4. Sincronização Final com Drive
    print("\n☁️ Sincronizando arquivos com Google Drive...")
    # Sincroniza TXTs
    for arq in os.listdir(LOCAL_BRAIN):
        if arq.endswith(".txt"):
            res_up = upload_ou_update(os.path.join(LOCAL_BRAIN, arq), arq, FOLDER_BRAIN_DRIVE)
            print(f"   ⬆️ {arq}: {res_up}")

    # Sincroniza Planilhas
    df_db.to_csv(DB_FILE, index=False, encoding='utf-8')
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    
    upload_ou_update(DB_FILE, 'base_conhecimento_auvp.csv', FOLDER_SHEETS_DRIVE)
    upload_ou_update(EXCEL_FILE, 'base_conhecimento_auvp.xlsx', FOLDER_SHEETS_DRIVE)

    print(f"\n🏆 HUB SINCRONIZADO! Banco e Cérebro atualizados localmente e na nuvem.")

if __name__ == "__main__":
    sardinha_hub_v16()