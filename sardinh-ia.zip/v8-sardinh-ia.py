import os
import time
import subprocess
import re
import io
import json
import pandas as pd
from datetime import datetime

# Bibliotecas PDF e Drive
from fpdf import FPDF
from fpdf.enums import XPos, YPos
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload

# ==========================================
# --- CONFIGURAÇÕES ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

FONTES_AUVP = {
    "Videos": "https://www.youtube.com/@investidorsardinha/videos",
    "Shorts": "https://www.youtube.com/@investidorsardinha/shorts",
    "Streams": "https://www.youtube.com/@investidorsardinha/streams",
    "Podcasts": "https://www.youtube.com/@investidorsardinha/podcasts",
    "Courses": "https://www.youtube.com/@investidorsardinha/courses",
    "Playlists": "https://www.youtube.com/@investidorsardinha/playlists"
}

LOCAL_BRAIN = 'cerebro_local'
LOCAL_GESTÃO = 'gestao_local'
DB_FILE = os.path.join(LOCAL_GESTÃO, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(LOCAL_GESTÃO, 'base_conhecimento_auvp.xlsx')
MAX_WORDS = 400000 

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_texto_para_pdf(texto):
    """Remove caracteres que o motor básico de PDF não consegue renderizar"""
    # Substitui caracteres comuns de quebra de layout
    texto = texto.replace('\t', ' ').replace('\r', '')
    # Mantém apenas caracteres imprimíveis básicos para evitar o erro de 'space'
    return "".join(c for c in texto if c.isprintable() or c == '\n')

def sanitizar_nome_arquivo(nome):
    if not nome: return "Geral"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str == 'NA': return "01/01/2000"
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return str(data_str)

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    texto_limpo = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
    res = []
    if texto_limpo:
        res.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i].lower() != texto_limpo[i-1].lower(): res.append(texto_limpo[i])
    return " ".join(res).strip()

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- DESIGNER: GERAÇÃO DE PDF ESTRUTURADO ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('helvetica', 'B', 14)
        self.set_text_color(255, 140, 0) # Laranja AUVP
        self.cell(0, 15, 'CONHECIMENTO AUVP', border=0, align='C', 
                  new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.ln(2)

    def footer(self):
        self.set_y(-15)
        self.set_font('helvetica', 'I', 8)
        self.cell(0, 10, f'Página {self.page_no()}', 0, 0, 'C')

def gerar_pdf_em_memoria(lista_blocos):
    """Gera PDF com margens e formatação de texto otimizadas"""
    pdf = AUVP_PDF()
    pdf.set_margins(left=15, top=15, right=15)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    
    for bloco in lista_blocos:
        # Sanitização profunda antes de enviar para o motor PDF
        limpo = sanitizar_texto_para_pdf(bloco)
        try:
            msg = limpo.encode('latin-1', 'replace').decode('latin-1')
        except:
            msg = limpo.encode('ascii', 'replace').decode('ascii')
            
        if "TITULO:" in msg:
            pdf.ln(5)
            pdf.set_font('helvetica', 'B', 12)
            pdf.set_text_color(0, 0, 0)
            pdf.multi_cell(w=0, h=8, txt=msg, border='B', align='L') # Borda inferior no título
            pdf.ln(2)
        elif "LINK:" in msg or "DATA:" in msg or "VIEWS:" in msg:
            pdf.set_font('helvetica', 'I', 9)
            pdf.set_text_color(100, 100, 100)
            pdf.multi_cell(w=0, h=5, txt=msg, align='L')
        else:
            pdf.set_font('helvetica', size=10)
            pdf.set_text_color(30, 30, 30)
            # w=0 garante que ele preencha até a margem direita
            pdf.multi_cell(w=0, h=6, txt=msg, align='L')
            pdf.ln(2)
            
    return pdf.output()

# ==========================================
# --- DRIVE SYNC ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
        creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def enviar_para_drive(service, nome, conteudo, folder_id, is_pdf=True):
    print(f"   ⬆️ Sincronizando: {nome}...")
    if is_pdf:
        fh = io.BytesIO(conteudo)
        mimetype = 'application/pdf'
    else:
        fh = io.BytesIO(conteudo.encode('utf-8-sig'))
        mimetype = 'text/csv' if nome.endswith('.csv') else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    
    media = MediaIoBaseUpload(fh, mimetype=mimetype, resumable=True)
    q = f"name = '{nome}' and '{folder_id}' in parents and trashed = false"
    res = service.files().list(q=q).execute().get('files', [])
    if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
    else: service.files().create(body={'name': nome, 'parents': [folder_id]}, media_body=media).execute()

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_engine_v32_2():
    print("\n" + "█"*75)
    print("🚀 SARDINHA ENGINE V32.2: THE DESIGNER EDITION")
    print("█"*75 + "\n")
    
    if not os.path.exists(LOCAL_BRAIN): os.makedirs(LOCAL_BRAIN)
    if not os.path.exists(LOCAL_GESTÃO): os.makedirs(LOCAL_GESTÃO)

    all_content = []
    print("📡 Mapeando todas as abas do canal...")
    for tipo, url in FONTES_AUVP.items():
        print(f"   🔎 Mapeando aba: {tipo}...")
        cmd = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', url]
        stdout = executar_comando(cmd)
        for line in stdout.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_content.append({
                    'id': parts[0], 'date': formatar_data(parts[1]), 
                    'views': parts[2], 'title': parts[3].strip(), 'tipo': tipo
                })

    df_full = pd.DataFrame(all_content).drop_duplicates(subset=['id'])
    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Tipo', 'Views', 'Status'])

    total = len(df_full)
    print(f"✅ {total} itens únicos identificados.")

    for idx, item in df_full.iterrows():
        v_id, v_title, v_date, v_tipo = item['id'], item['title'], item['date'], item['tipo']
        v_link = f"https://www.youtube.com/watch?v={v_id}"
        nome_txt_arquivo = f"Base_{v_tipo}.txt"
        caminho_local_txt = os.path.join(LOCAL_BRAIN, nome_txt_arquivo)
        prefix = f"[{idx+1}/{total}]"

        if v_title in ['[Private video]', '[Deleted video]']: continue

        if os.path.exists(caminho_local_txt):
            with open(caminho_local_txt, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if v_link in f.read():
                    print(f"{prefix} ⏭️  Pular: {v_title[:45]}...")
                    continue

        print(f"{prefix} 🎬 Extraindo: {v_title[:40]}...")
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            vtt = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            if vtt:
                texto = limpar_vtt(vtt[0])
                if len(texto) > 100:
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\nTITULO: {v_title}\n")
                        f.write(f"TIPO: {v_tipo} | DATA: {v_date} | VIEWS: {item['views']}\n")
                        f.write(f"LINK: {v_link}\n")
                        f.write(f"CONTEÚDO:\n{texto}\n")
                        f.write("="*50 + "\n")
                    
                    nova_linha = {'ID': v_id, 'Data_Pub': v_date, 'Link': v_link, 'Titulo': v_title, 'Tipo': v_tipo, 'Views': item['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True).drop_duplicates(subset=['ID'])
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                    print(f"      ✅ Sucesso!")
                os.remove(vtt[0])
            else: print(f"      ❌ Sem legenda.")
            time.sleep(1.5)
        except Exception as e: print(f"      ❌ Erro: {e}")

    # Sincronização Cloud
    print("\n📊 Gerando PDFs estruturados e Sincronizando...")
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    
    service = get_drive_service()
    for arq_txt in os.listdir(LOCAL_BRAIN):
        if arq_txt.endswith(".txt"):
            nome_base = arq_txt.replace(".txt", "")
            with open(os.path.join(LOCAL_BRAIN, arq_txt), 'r', encoding='utf-8-sig', errors='replace') as f:
                blocos = f.read().split("="*50)
            
            lote_pdf = []; words = 0; parte = 1
            for b in blocos:
                if not b.strip(): continue
                w = len(b.split())
                if words + w > MAX_WORDS:
                    enviar_para_drive(service, f"{nome_base}_Parte_{parte}.pdf", gerar_pdf_em_memoria(lote_pdf), FOLDER_BRAIN_DRIVE)
                    lote_pdf = [b]; words = w; parte += 1
                else:
                    lote_pdf.append(b + "\n" + "="*50)
                    words += w
            if lote_pdf:
                nome_f = f"{nome_base}_Parte_{parte}.pdf" if parte > 1 else f"{nome_base}.pdf"
                enviar_para_drive(service, nome_f, gerar_pdf_em_memoria(lote_pdf), FOLDER_BRAIN_DRIVE)

    # Upload Planilhas
    enviar_para_drive(service, 'base_conhecimento_auvp.csv', df_db.to_csv(index=False, encoding='utf-8-sig'), FOLDER_SHEETS_DRIVE, is_pdf=False)
    with open(EXCEL_FILE, 'rb') as f:
        enviar_para_drive(service, 'base_conhecimento_auvp.xlsx', f.read(), FOLDER_SHEETS_DRIVE, is_pdf=False)

    print(f"\n🏆 DRIVE ATUALIZADO! Layout dos PDFs corrigido.")

if __name__ == "__main__":
    sardinha_engine_v32_2()