import os
import time
import subprocess
import re
import io
import json
import pandas as pd
from datetime import datetime

# Bibliotecas PDF (fpdf2)
from fpdf import FPDF
from fpdf.enums import XPos, YPos

# Bibliotecas Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload

# ==========================================
# --- CONFIGURAÇÕES ---
# ==========================================
# IDs do Google Drive (Substitua se necessário)
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

# Configurações Locais (v4 style)
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
OUTPUT_FOLDER_TXT = 'cerebro_local' 
GESTÃO_FOLDER = 'gestao_local'
DB_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.xlsx')
MAX_WORDS = 400000 

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    if not nome: return "Sem_Nome"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str in ['NA', 'None']: return "Data Indisponível"
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return str(data_str)

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    texto = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
    res = []
    if texto:
        res.append(texto[0])
        for i in range(1, len(texto)):
            if texto[i].lower() != texto[i-1].lower(): res.append(texto[i])
    return " ".join(res).strip()

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- GERAÇÃO DE PDF EM MEMÓRIA ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('helvetica', 'B', 12)
        self.cell(0, 10, 'BASE DE CONHECIMENTO AUVP', border=0, new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        self.ln(5)

def gerar_pdf_em_memoria(lista_blocos):
    """Gera o PDF e retorna os bytes brutos"""
    pdf = AUVP_PDF()
    pdf.add_page()
    pdf.set_font("helvetica", size=10)
    largura_util = pdf.epw # Fix: Resolve horizontal space error

    for bloco in lista_blocos:
        msg = bloco.encode('latin-1', 'replace').decode('latin-1')
        if "TITULO:" in msg:
            pdf.set_font("helvetica", 'B', 11)
            pdf.multi_cell(largura_util, 8, msg)
            pdf.set_font("helvetica", size=10)
        else:
            pdf.multi_cell(largura_util, 5, msg)
    return pdf.output()

# ==========================================
# --- DRIVE SYNC & SPLITTER ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def sincronizar_e_particionar_final():
    print("\n☁️  Iniciando Sincronização Final In-Memory...")
    service = get_drive_service()
    
    for arq_txt in os.listdir(OUTPUT_FOLDER_TXT):
        if arq_txt.endswith(".txt"):
            caminho_txt = os.path.join(OUTPUT_FOLDER_TXT, arq_txt)
            nome_base = arq_txt.replace(".txt", "")
            
            with open(caminho_txt, 'r', encoding='utf-8-sig', errors='replace') as f:
                videos = f.read().split("="*50)
            
            lote_atual = []; word_count = 0; parte = 1

            for v in videos:
                if not v.strip(): continue
                v_words = len(v.split())
                if word_count + v_words > MAX_WORDS:
                    enviar_lote(service, f"{nome_base} - Parte {parte}.pdf", lote_atual)
                    lote_atual = [v]; word_count = v_words; parte += 1
                else:
                    lote_atual.append(v + "\n" + "="*50)
                    word_count += v_words
            
            if lote_atual:
                nome_f = f"{nome_base} - Parte {parte}.pdf" if parte > 1 else f"{nome_base}.pdf"
                enviar_lote(service, nome_f, lote_atual)

def enviar_lote(service, nome_arquivo, blocos):
    """Gera PDF e sobe pro Drive sem usar arquivos temporários no HD"""
    print(f"   ⬆️ Enviando: {nome_arquivo}...")
    pdf_bytes = gerar_pdf_em_memoria(blocos)
    fh = io.BytesIO(pdf_bytes)
    media = MediaIoBaseUpload(fh, mimetype='application/pdf', resumable=True)
    
    q = f"name = '{nome_arquivo}' and '{FOLDER_BRAIN_DRIVE}' in parents and trashed = false"
    res = service.files().list(q=q).execute().get('files', [])
    
    if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
    else: service.files().create(body={'name': nome_arquivo, 'parents': [FOLDER_BRAIN_DRIVE]}, media_body=media).execute()
    print(f"      ✅ Sincronizado!")

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_engine_v27():
    print("\n" + "█"*75)
    print("🚀 SARDINHA ENGINE V27: THE FINAL SOLUTION")
    print("█"*75 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER_TXT): os.makedirs(OUTPUT_FOLDER_TXT)
    if not os.path.exists(GESTÃO_FOLDER): os.makedirs(GESTÃO_FOLDER)

    print("📡 Localizando playlists...")
    stdout_p = executar_comando(['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL])
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines): playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    all_videos = []
    print(f"✅ {len(playlists_info)} Playlists mapeadas. Extraindo Metadados...")
    for p in playlists_info:
        stdout_v = executar_comando(['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', f"https://www.youtube.com/playlist?list={p['id']}"])
        for line in stdout_v.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_videos.append({'id': parts[0], 'date': formatar_data(parts[1]), 'views': parts[2], 'title': parts[3], 'playlist': p['title']})

    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    total = len(all_videos)
    for idx, video in enumerate(all_videos, 1):
        v_id, v_title, v_date = video['id'], video['title'], video['date']
        v_link = f"https://www.youtube.com/watch?v={v_id}"
        nome_txt = f"{sanitizar_nome(video['playlist'])}.txt"
        caminho_local_txt = os.path.join(OUTPUT_FOLDER_TXT, nome_txt)

        if v_title in ['[Private video]', '[Deleted video]']: continue
        if os.path.exists(caminho_local_txt):
            with open(caminho_local_txt, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if v_link in f.read():
                    print(f"[{idx}/{total}] ⏭️  Pular: {v_title[:45]}...")
                    continue

        print(f"[{idx}/{total}] 🎬 Extraindo: {v_title[:45]}...")
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            vtt = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            if vtt:
                texto = limpar_vtt(vtt[0])
                if len(texto) > 150:
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\nTITULO: {v_title}\nDATA: {v_date}\nVIEWS: {video['views']}\nLINK: {v_link}\nCONTEÚDO:\n{texto}\n" + "="*50 + "\n")
                    nova_linha = {'ID': v_id, 'Data_Pub': v_date, 'Link': v_link, 'Titulo': v_title, 'Playlist': video['playlist'], 'Views': video['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                    print(f"      ✅ Sucesso!")
                os.remove(vtt[0])
            else: print(f"      ❌ Sem legenda.")
            time.sleep(2)
        except Exception as e: print(f"      ❌ Erro: {e}")

    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    sincronizar_e_particionar_final()
    
    # Upload Planilhas
    service = get_drive_service()
    for path, name in [(DB_FILE, 'base_conhecimento_auvp.csv'), (EXCEL_FILE, 'base_conhecimento_auvp.xlsx')]:
        media = MediaFileUpload(path, resumable=True)
        q = f"name = '{name}' and '{FOLDER_SHEETS_DRIVE}' in parents and trashed = false"
        res = service.files().list(q=q).execute().get('files', [])
        if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
        else: service.files().create(body={'name': name, 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media).execute()

if __name__ == "__main__":
    sardinha_engine_v27()