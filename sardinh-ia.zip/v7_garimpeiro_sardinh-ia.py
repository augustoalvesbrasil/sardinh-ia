import os
import time
import subprocess
import re
import pandas as pd
from datetime import datetime
from google.cloud import storage

# --- CONFIGURAÇÕES ---
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "google_key.json"
BUCKET_NAME = "cerebro-sardinha-dados"
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
DB_FILE = 'base_conhecimento_auvp.csv'
EXCEL_FILE = 'base_conhecimento_auvp.xlsx'
OUTPUT_FOLDER = 'cerebro_auvp_playlists'

DICIONARIO_RAUL = {
    "Renode": "Hinode", "Renodê": "Hinode", "Rino": "Hinode",
    "Selyc": "Selic", "b tg": "BTG Pactual", "au vp": "AUVP",
    "diagrama do cerrado": "Diagrama do Cerrado", "investidor sardinha": "Investidor Sardinha"
}

def sanitizar_nome_arquivo(nome):
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str in ['NA', 'None']: return "01/01/2000"
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    try:
        with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
            linhas = f.readlines()
        texto_puro = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
        bruto = " ".join(texto_puro).split()
        res = []
        if bruto:
            res.append(bruto[0])
            for i in range(1, len(bruto)):
                if bruto[i].lower() != bruto[i-1].lower(): res.append(bruto[i])
        texto = " ".join(res)
        texto = texto.replace("&gt;", ">").replace("&lt;", "<").replace("&nbsp;", " ")
        for erro, correcao in DICIONARIO_RAUL.items():
            texto = re.sub(erro, correcao, texto, flags=re.IGNORECASE)
        return re.sub(r'\s+', ' ', texto).strip()
    except: return ""

def verificar_integridade(caminho_arquivo, link_video):
    """Verifica se o arquivo físico existe e se o vídeo está lá dentro"""
    if not os.path.exists(caminho_arquivo):
        return False
    try:
        with open(caminho_arquivo, 'r', encoding='utf-8') as f:
            return link_video in f.read()
    except:
        return False

def upload_cloud(arquivo_local, nome_nuvem):
    try:
        client = storage.Client()
        bucket = client.bucket(BUCKET_NAME)
        blob = bucket.blob(f"conhecimento/{nome_nuvem}")
        blob.upload_from_filename(arquivo_local)
        return True
    except: return False

def executar_comando(cmd):
    try:
        result = subprocess.run(cmd, capture_output=True, text=False)
        return result.stdout.decode('utf-8', errors='replace')
    except: return ""

def sardinha_engine_v11_1():
    print("\n" + "█"*65)
    print("🚀 SARDINHA ENGINE V11.1: DOUBLE CHECK EDITION (CSV + FS)")
    print("█"*65 + "\n")

    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)
    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    print("📡 Escaneando canal...")
    stdout_p = executar_comando(['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL])
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    
    all_videos = []
    for i in range(0, len(p_lines), 2):
        p_title, p_id = p_lines[i], p_lines[i+1]
        print(f"   📂 Playlist: {p_title[:40]}...")
        stdout_v = executar_comando(['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', f"https://www.youtube.com/playlist?list={p_id}"])
        for line in stdout_v.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_videos.append({'id': parts[0], 'date': formatar_data(parts[1]), 'views': parts[2], 'title': parts[3], 'playlist': p_title})

    total_canal = len(all_videos)
    print(f"\n📊 Total: {total_canal} vídeos. Iniciando Double Check...")

    for idx, video in enumerate(all_videos, 1):
        v_id, v_title, v_link = video['id'], video['title'], f"https://www.youtube.com/watch?v={video['id']}"
        caminho_local_txt = os.path.join(OUTPUT_FOLDER, f"{sanitizar_nome_arquivo(video['playlist'])}.txt")
        
        # DOUBLE CHECK: CSV + Arquivo Físico + Conteúdo
        ja_no_csv = v_id in df_db['ID'].values
        integro = verificar_integridade(caminho_local_txt, v_link)

        if ja_no_csv and integro:
            print(f"[{idx}/{total_canal}] ⏭️  Pular: {v_title[:45]} (OK)")
            continue

        # Se chegou aqui, é porque o CSV mentiu ou o arquivo sumiu. Forçar mineração.
        print(f"[{idx}/{total_canal}] 🎬 {'Reparando' if ja_no_csv else 'Extraindo'}: {v_title[:45]}...")
        
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            vtt_file = f"{temp_out}.pt.vtt"
            if os.path.exists(vtt_file):
                texto = limpar_vtt(vtt_file)
                if len(texto) > 150:
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\n{'='*60}\nTITULO: {v_title}\nDATA: {video['date']}\nVIEWS: {video['views']}\nLINK: {v_link}\n{'-'*60}\nCONTEÚDO:\n{texto}\n{'='*60}\n")
                    
                    upload_cloud(caminho_local_txt, f"{sanitizar_nome_arquivo(video['playlist'])}.txt")

                    # Se já existia no CSV mas o arquivo sumiu, removemos o antigo para re-inserir o novo
                    if ja_no_csv:
                        df_db = df_db[df_db['ID'] != v_id]
                    
                    nova_linha = {'ID': v_id, 'Data_Pub': video['date'], 'Link': v_link, 'Titulo': v_title, 'Playlist': video['playlist'], 'Views': video['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8')
                    print(f"      ✅ Sucesso!")
                
                if os.path.exists(vtt_file): os.remove(vtt_file)
            else:
                print(f"      ❌ Sem transcrição.")
            time.sleep(2)
        except Exception as e:
            print(f"      ❌ Erro: {e}")

    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    print(f"\n🏆 CONCLUÍDO! Banco e arquivos em sincronia total.")

if __name__ == "__main__":
    sardinha_engine_v11_1()