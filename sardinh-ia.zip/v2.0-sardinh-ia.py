import os
import time
import subprocess
import re
import io
import pandas as pd
from datetime import datetime
from fpdf import FPDF
from fpdf.enums import XPos, YPos

# Bibliotecas Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# ==========================================
# --- CONFIGURAÇÕES DRIVE ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

# --- CONFIGURAÇÕES LOCAIS ---
CANAL_URL = 'https://www.youtube.com/@InvestidorSardinha'
OUTPUT_FOLDER_TXT = 'cerebro_local' 
GESTÃO_FOLDER = 'gestao_local'
DB_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.xlsx')

# HIERARQUIA DE COLETA (Para evitar duplicados)
ABAS_HIERARQUIA = [
    {"tipo": "Curso", "url": f"{CANAL_URL}/courses"},
    {"tipo": "Playlist", "url": f"{CANAL_URL}/playlists"},
    {"tipo": "Podcast", "url": f"{CANAL_URL}/podcasts"},
    {"tipo": "Stream", "url": f"{CANAL_URL}/streams"},
    {"tipo": "Short", "url": f"{CANAL_URL}/shorts"},
    {"tipo": "Video_Geral", "url": f"{CANAL_URL}/videos"}
]

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    if not nome: return "Sem_Nome"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str == 'NA': return "01/01/2000"
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_vtt_avancado(caminho_vtt):
    """Remove o efeito de scrolling das legendas (repetições de frases)"""
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    
    # Remove tags e timestamps
    texto_bruto = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
    
    res = []
    ultima_linha = ""
    for linha in texto_bruto:
        if not linha or linha == ultima_linha: continue
        # Lógica ANTI-LIXO: Se a linha atual contém a anterior (scrolling), substitui
        if ultima_linha.lower() in linha.lower():
            if res: res.pop()
        res.append(linha)
        ultima_linha = linha
        
    return " ".join(res).strip()

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- LIBRARIAN: GERAÇÃO DE PDF ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('helvetica', 'B', 12)
        self.cell(0, 10, 'BASE DE CONHECIMENTO AUVP', border=0, 
                  new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        self.ln(5)

def gerar_pdf_da_playlist(caminho_txt, nome_pdf):
    print(f"   📑 Criando PDF: {nome_pdf}...")
    pdf = AUVP_PDF()
    pdf.add_page()
    pdf.set_font("helvetica", size=10)
    
    with open(caminho_txt, 'r', encoding='utf-8-sig', errors='replace') as f:
        for linha in f:
            msg = linha.encode('latin-1', 'replace').decode('latin-1')
            if "TITULO:" in linha:
                pdf.set_font("helvetica", 'B', 11)
                pdf.multi_cell(0, 8, msg)
                pdf.set_font("helvetica", size=10)
            else:
                pdf.multi_cell(0, 5, msg)
    
    caminho_pdf = caminho_txt.replace(".txt", ".pdf")
    pdf.output(caminho_pdf)
    return caminho_pdf

# ==========================================
# --- DRIVE SYNC ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
        creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def sincronizar_final_cloud():
    print("\n☁️  Iniciando Sincronização Final com Drive...")
    service = get_drive_service()

    # PDFs
    for arq in os.listdir(OUTPUT_FOLDER_TXT):
        if arq.endswith(".txt"):
            txt_local = os.path.join(OUTPUT_FOLDER_TXT, arq)
            nome_pdf = arq.replace(".txt", ".pdf")
            pdf_local = gerar_pdf_da_playlist(txt_local, nome_pdf)
            
            media = MediaFileUpload(pdf_local, mimetype='application/pdf')
            q = f"name = '{nome_pdf}' and '{FOLDER_BRAIN_DRIVE}' in parents"
            res = service.files().list(q=q).execute().get('files', [])
            
            if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
            else: service.files().create(body={'name': nome_pdf, 'parents': [FOLDER_BRAIN_DRIVE]}, media_body=media).execute()
            
            print(f"      ✅ Drive: {nome_pdf} OK")
            time.sleep(1)
            if os.path.exists(pdf_local): os.remove(pdf_local)

    # Planilhas
    for path, nome_drive in [(DB_FILE, 'base_conhecimento_auvp.csv'), (EXCEL_FILE, 'base_conhecimento_auvp.xlsx')]:
        if os.path.exists(path):
            media = MediaFileUpload(path)
            q = f"name = '{nome_drive}' and '{FOLDER_SHEETS_DRIVE}' in parents"
            res = service.files().list(q=q).execute().get('files', [])
            if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
            else: service.files().create(body={'name': nome_drive, 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media).execute()
            print(f"   📊 Planilha: {nome_drive} OK.")

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_engine_v41():
    print("\n" + "█"*75)
    print("🚀 SARDINHA ENGINE V41: THE MASTER ARCHITECT (Sequencial)")
    print("█"*75 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER_TXT): os.makedirs(OUTPUT_FOLDER_TXT)
    if not os.path.exists(GESTÃO_FOLDER): os.makedirs(GESTÃO_FOLDER)

    if os.path.exists(DB_FILE):
        df_db = pd.read_csv(DB_FILE, dtype=str)
        ids_processados = set(df_db['ID'].tolist())
    else:
        df_db = pd.DataFrame(columns=['ID', 'Data', 'Link', 'Titulo', 'Tipo', 'Nome', 'Views'])
        ids_processados = set()

    # LOOP POR ABAS (EXIGÊNCIA 1)
    for aba in ABAS_HIERARQUIA:
        print(f"\n📂 SETOR: {aba['tipo'].upper()}")
        print("📡 Localizando vídeos...")
        
        # Mapeamento v23.2 style
        stdout_v = executar_comando(['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s|||%(playlist_title)s', aba['url']])
        linhas = [l for l in stdout_v.split('\n') if '|||' in l]
        
        print(f"📊 {len(linhas)} vídeos encontrados na aba {aba['tipo']}.")

        for idx, item in enumerate(linhas, 1):
            p = item.split('|||')
            v_id, v_data, v_views, v_titulo = p[0], p[1], p[2], p[3]
            v_nome_origem = p[4] if (len(p) > 4 and p[4] != 'NA') else aba['tipo']
            v_link = f"https://www.youtube.com/watch?v={v_id}"
            
            prefix = f"[{idx}/{len(linhas)}]"

            # DEDUPLICAÇÃO GLOBAL E LOCAL (EXIGÊNCIA 5 e 6)
            if v_id in ids_processados:
                print(f"{prefix} ⏭️  Pular: {v_titulo[:40]}... (Já existe)")
                continue

            if v_titulo in ['[Private video]', '[Deleted video]']: continue

            print(f"{prefix} 🎬 Extraindo: {v_titulo[:40]}...", end="\r")
            
            try:
                temp_out = f"temp_{v_id}"
                subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt.*', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                
                vtt_files = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
                
                if vtt_files:
                    texto = limpar_vtt_avancado(vtt_files[0]) # EXIGÊNCIA ANTI-LIXO
                    if len(texto) > 150:
                        txt_path = os.path.join(OUTPUT_FOLDER_TXT, f"{sanitizar_nome(v_nome_origem)}.txt")
                        with open(txt_path, "a", encoding="utf-8-sig") as f:
                            data_f = formatar_data(v_data)
                            f.write(f"\nTITULO: {v_titulo}\nDATA: {data_f}\nLINK: {v_link}\nTIPO: {aba['tipo']}\nCONTEUDO:\n{texto}\n" + "="*50 + "\n")
                        
                        # ALIMENTA PLANILHA (EXIGÊNCIA 2)
                        nova_row = {'ID': v_id, 'Data': data_f, 'Link': v_link, 'Titulo': v_titulo, 'Tipo': aba['tipo'], 'Nome': v_nome_origem, 'Views': v_views}
                        df_db = pd.concat([df_db, pd.DataFrame([nova_row])], ignore_index=True)
                        ids_processados.add(v_id)
                        
                        df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                        print(f"{prefix} ✅ Sucesso! Transcrição salva.")
                    for f in vtt_files: os.remove(f)
                else:
                    print(f"{prefix} ❌ Falha: Sem transcrição disponível.")
                
                time.sleep(1) 
            except Exception as e:
                print(f"{prefix} ❌ Erro: {e}")

    # FINALIZAÇÃO (EXIGÊNCIA 7 e 8)
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    sincronizar_final_cloud()
    print(f"\n🏆 PROCESSO CONCLUÍDO! Drive e Planilhas atualizados.")

if __name__ == "__main__":
    sardinha_engine_v41()