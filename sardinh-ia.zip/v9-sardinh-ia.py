import os
import time
import subprocess
import re
import io
import json
import pandas as pd
from datetime import datetime

# Bibliotecas PDF e Drive
from fpdf import FPDF
from fpdf.enums import XPos, YPos
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload

# ==========================================
# --- CONFIGURAÇÕES ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

# FONTES DE MÍDIA (Aba Posts removida por ser incompatível com extração de áudio/legenda)
FONTES_AUVP = {
    "Videos": "https://www.youtube.com/@investidorsardinha/videos",
    "Shorts": "https://www.youtube.com/@investidorsardinha/shorts",
    "Streams": "https://www.youtube.com/@investidorsardinha/streams",
    "Podcasts": "https://www.youtube.com/@investidorsardinha/podcasts",
    "Courses": "https://www.youtube.com/@investidorsardinha/courses"
}

LOCAL_BRAIN = 'cerebro_local'
LOCAL_GESTÃO = 'gestao_local'
DB_FILE = os.path.join(LOCAL_GESTÃO, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(LOCAL_GESTÃO, 'base_conhecimento_auvp.xlsx')
MAX_WORDS = 400000 

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_texto_pdf(texto):
    """Filtra caracteres para evitar quebras de margem no PDF"""
    return "".join(c for c in texto if c.isprintable() or c == '\n')

def formatar_data_br(data_raw):
    """Converte YYYYMMDD para DD/MM/YYYY com segurança"""
    if not data_raw or data_raw == 'NA': return "Data não informada"
    try:
        return datetime.strptime(str(data_raw), '%Y%m%d').strftime('%d/%m/%Y')
    except:
        return str(data_raw)

def executar_comando(cmd):
    """Captura saída do terminal sem crash de encoding"""
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- PDF DESIGNER (FIXED MARGINS) ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('helvetica', 'B', 12)
        self.set_text_color(255, 140, 0)
        self.cell(0, 10, 'REPOSITÓRIO DE INTELIGÊNCIA AUVP', border=0, align='C', 
                  new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.ln(5)

def gerar_pdf_final(lista_blocos):
    pdf = AUVP_PDF()
    pdf.set_margins(15, 15, 15)
    pdf.add_page()
    
    for bloco in lista_blocos:
        texto = sanitizar_texto_pdf(bloco)
        try:
            msg = texto.encode('latin-1', 'replace').decode('latin-1')
        except:
            msg = texto.encode('ascii', 'replace').decode('ascii')

        if "TITULO:" in msg:
            pdf.ln(4)
            pdf.set_font('helvetica', 'B', 11)
            pdf.set_text_color(0, 0, 0)
            pdf.multi_cell(0, 7, msg, border='B', align='L')
            pdf.ln(2)
        elif any(tag in msg for tag in ["LINK:", "DATA:", "VIEWS:", "TIPO:"]):
            pdf.set_font('helvetica', 'I', 8)
            pdf.set_text_color(120, 120, 120)
            pdf.multi_cell(0, 5, msg, align='L')
        else:
            pdf.set_font('helvetica', size=10)
            pdf.set_text_color(40, 40, 40)
            pdf.multi_cell(0, 6, msg, align='L')
    return pdf.output()

# ==========================================
# --- MOTOR DE MINERAÇÃO ---
# ==========================================

def sardinha_engine_v33():
    print("\n🚀 SARDINHA ENGINE V33: THE MASTER ARCHIVIST")
    
    if not os.path.exists(LOCAL_BRAIN): os.makedirs(LOCAL_BRAIN)
    if not os.path.exists(LOCAL_GESTÃO): os.makedirs(LOCAL_GESTÃO)

    all_items = []
    print("📡 Mapeando todas as mídias do canal (Vídeos, Shorts, Podcasts, Cursos)...")
    
    for tipo, url in FONTES_AUVP.items():
        print(f"   🔎 Varrendo aba: {tipo}...")
        cmd = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', url]
        stdout = executar_comando(cmd)
        for line in stdout.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_items.append({
                    'id': parts[0], 'date': formatar_data_br(parts[1]), 
                    'views': parts[2], 'title': parts[3].strip(), 'tipo': tipo
                })

    df_full = pd.DataFrame(all_items).drop_duplicates(subset=['id'])
    
    # Carregar Banco de Dados Local
    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Tipo', 'Views', 'Status'])

    total = len(df_full)
    print(f"✅ {total} itens únicos mapeados com sucesso.")

    for idx, item in df_full.iterrows():
        v_id, v_title, v_link = item['id'], item['title'], f"https://www.youtube.com/watch?v={item['id']}"
        v_tipo = item['tipo']
        caminho_txt = os.path.join(LOCAL_BRAIN, f"Base_{v_tipo}.txt")
        prefix = f"[{idx+1}/{total}]"

        if v_title in ['[Private video]', '[Deleted video]']: continue

        # Check de Existência Local
        if os.path.exists(caminho_txt):
            with open(caminho_txt, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if v_link in f.read():
                    print(f"{prefix} ⏭️  Pular: {v_title[:45]}...")
                    continue

        print(f"{prefix} 🎬 Minerando: {v_title[:45]}...")
        try:
            temp_out = f"temp_{v_id}"
            # Extração de transcrição v1/v4 (estável)
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            vtt = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            
            if vtt:
                with open(vtt[0], 'r', encoding='utf-8', errors='replace') as f_vtt:
                    linhas = f_vtt.readlines()
                    # Limpeza v1 lógica
                    texto_puro = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
                    corpo = " ".join(texto_puro).strip()

                if len(corpo) > 100:
                    with open(caminho_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\nTITULO: {v_title}\nTIPO: {v_tipo}\nDATA: {item['date']}\nVIEWS: {item['views']}\nLINK: {v_link}\nCONTEÚDO:\n{corpo}\n" + "="*50 + "\n")
                    
                    nova_linha = {'ID': v_id, 'Data_Pub': item['date'], 'Link': v_link, 'Titulo': v_title, 'Tipo': v_tipo, 'Views': item['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True).drop_duplicates(subset=['ID'])
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                    print(f"      ✅ OK!")
                os.remove(vtt[0])
            else: print(f"      ❌ Sem legenda.")
            time.sleep(1.5)
        except Exception as e: print(f"      ❌ Erro: {e}")

    # Sincronização Final Cloud com Splitter e PDF Designer
    print("\n📊 Sincronizando com Drive e gerando PDFs Particionados...")
    # [A lógica de upload in-memory v27 continua aqui para PDFs e Planilhas]

if __name__ == "__main__":
    sardinha_engine_v33()