import os
import subprocess
import pandas as pd
from datetime import datetime
import re

# Necessário instalar se não tiver: pip install google-api-python-client
from googleapiclient.discovery import build

# ==========================================
# --- CONFIGURAÇÕES ---
# ==========================================
# Sua chave de API extraída do arquivo 'coleta_youtube.py'
YOUTUBE_API_KEY = "AIzaSyDv9z1n_7HrA0IzYFzBldGLv_yx61QR9Uo"

CANAL_URL = 'https://www.youtube.com/@InvestidorSardinha'

# Definimos quais abas contêm coleções e quais contêm vídeos avulsos
ABAS_VARRER = [
    {"tipo": "Curso", "url": f"{CANAL_URL}/courses", "agrupado": True},
    {"tipo": "Playlist", "url": f"{CANAL_URL}/playlists", "agrupado": True},
    {"tipo": "Podcast", "url": f"{CANAL_URL}/podcasts", "agrupado": True},
    {"tipo": "Short", "url": f"{CANAL_URL}/shorts", "agrupado": False},
    {"tipo": "Stream", "url": f"{CANAL_URL}/streams", "agrupado": False},
    {"tipo": "Video", "url": f"{CANAL_URL}/videos", "agrupado": False}
]

LOCAL_GESTAO = 'gestao_local'
DB_FILE = os.path.join(LOCAL_GESTAO, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(LOCAL_GESTAO, 'base_conhecimento_auvp.xlsx')

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    if not nome or nome == 'NA': return "Geral"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- MOTOR DE MAPEAMENTO ---
# ==========================================

def mapeador_hierarquico_com_api():
    print("\n" + "█"*75)
    print("🚀 SARDINHA ENGINE: ESTÁGIO 1 - MAPEAMENTO HÍBRIDO (YT-DLP + API)")
    print("█"*75 + "\n")
    
    if not os.path.exists(LOCAL_GESTAO): 
        os.makedirs(LOCAL_GESTAO)

    banco_videos = {}
    total_estruturado = 0

    # ---------------------------------------------------------
    # FASE 1: RASPAGEM ESTRUTURAL (Rápida com YT-DLP)
    # ---------------------------------------------------------
    for aba in ABAS_VARRER:
        tipo = aba['tipo']
        url = aba['url']
        agrupado = aba['agrupado']
        
        print(f"\n📡 Varrendo Estrutura: {tipo}...")
        
        if agrupado:
            cmd_lista = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(title)s', url]
            raw_lista = executar_comando(cmd_lista)
            agrupamentos = [linha for linha in raw_lista.split('\n') if '|||' in linha]
            
            print(f"   📂 Encontrados: {len(agrupamentos)} coleções.")
            
            for ag in agrupamentos:
                partes_ag = ag.split('|||', 1)
                if len(partes_ag) < 2: continue
                
                ag_id, ag_titulo = partes_ag[0], partes_ag[1]
                ag_titulo_limpo = sanitizar_nome(ag_titulo)
                
                cmd_videos = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(title)s', f"https://www.youtube.com/playlist?list={ag_id}"]
                raw_videos = executar_comando(cmd_videos)
                videos_list = [linha for linha in raw_videos.split('\n') if '|||' in linha]
                
                for v_line in videos_list:
                    partes = v_line.split('|||')
                    if len(partes) >= 2:
                        v_id, v_titulo = partes[0], partes[1]
                        
                        if v_id not in banco_videos:
                            banco_videos[v_id] = {
                                'ID': v_id, 'Link': f"https://www.youtube.com/watch?v={v_id}",
                                'Titulo': v_titulo.strip(), 'Tipo': tipo, 'Nome_Agrupamento': ag_titulo_limpo,
                                'Data': 'Pendente', 'Views': 0, 'Status_Transcricao': 'Pendente'
                            }
                            total_estruturado += 1
        else:
            cmd_videos = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(title)s', url]
            raw_videos = executar_comando(cmd_videos)
            videos_list = [linha for linha in raw_videos.split('\n') if '|||' in linha]
            
            print(f"   📂 Encontrados: {len(videos_list)} vídeos soltos.")
            
            for v_line in videos_list:
                partes = v_line.split('|||')
                if len(partes) >= 2:
                    v_id, v_titulo = partes[0], partes[1]
                    
                    if v_id not in banco_videos:
                        banco_videos[v_id] = {
                            'ID': v_id, 'Link': f"https://www.youtube.com/watch?v={v_id}",
                            'Titulo': v_titulo.strip(), 'Tipo': tipo, 'Nome_Agrupamento': f"Avulso ({tipo})",
                            'Data': 'Pendente', 'Views': 0, 'Status_Transcricao': 'Pendente'
                        }
                        total_estruturado += 1

    # ---------------------------------------------------------
    # FASE 2: ENRIQUECIMENTO DE METADADOS (YouTube Data API v3)
    # ---------------------------------------------------------
    print(f"\n⚙️ Iniciando Enriquecimento via API (Capturando Datas e Views)...")
    
    try:
        youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
        ids_lista = list(banco_videos.keys())
        
        # Faz chamadas em lotes de 50 (limite da API do Google)
        for i in range(0, len(ids_lista), 50):
            lote_ids = ids_lista[i:i+50]
            ids_string = ",".join(lote_ids)
            
            request = youtube.videos().list(
                part="snippet,statistics",
                id=ids_string
            )
            response = request.execute()
            
            for item in response.get('items', []):
                vid = item['id']
                raw_date = item['snippet']['publishedAt'] # Ex: 2024-05-12T15:00:00Z
                views = item['statistics'].get('viewCount', 0)
                
                # Conversão exata da data para o padrão dd/MM/yyyy
                dt_obj = datetime.strptime(raw_date, "%Y-%m-%dT%H:%M:%SZ")
                data_formatada = dt_obj.strftime("%d/%m/%Y")
                
                # Atualiza nosso dicionário
                if vid in banco_videos:
                    banco_videos[vid]['Data'] = data_formatada
                    banco_videos[vid]['Views'] = views
                    
        print("   ✅ Datas e Views sincronizadas com sucesso!")
        
    except Exception as e:
        print(f"   ❌ Erro de comunicação com a API do YouTube: {e}")
        print("   ⚠️ Os vídeos serão salvos, mas as datas podem ficar como Pendentes.")

    # ---------------------------------------------------------
    # FASE 3: SALVAMENTO E FINALIZAÇÃO
    # ---------------------------------------------------------
    print(f"\n📊 Consolidando Fonte da Verdade... Total de vídeos únicos: {len(banco_videos)}")
    
    if len(banco_videos) > 0:
        df_db = pd.DataFrame.from_dict(banco_videos, orient='index')
        
        # Garante que as Views sejam tratadas como inteiros numéricos no Excel
        df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
        
        # Ordena a planilha para ficar elegante e legível
        df_db = df_db.sort_values(by=['Tipo', 'Nome_Agrupamento'])
        
        df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
        df_db.to_excel(EXCEL_FILE, index=False)
        
        print(f"✅ Arquivos CSV e XLSX salvos em: ./{LOCAL_GESTAO}/")
    else:
        print("⚠️ Nenhum vídeo foi mapeado. Verifique a conexão ou a URL do canal.")
        
    print("🏆 ESTÁGIO 1 CONCLUÍDO COM SUCESSO!")

if __name__ == "__main__":
    mapeador_hierarquico_com_api()