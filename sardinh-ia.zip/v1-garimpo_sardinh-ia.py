import pandas as pd
import os
import time
import subprocess
import re

# --- CONFIGURAÇÕES ---
ARQUIVO_CSV = 'videos_por_playlist.csv'
OUTPUT_FOLDER = 'cerebro_auvp_playlists'

def limpar_vtt(caminho_vtt):
    """Lógica para limpar o arquivo de legenda do YouTube (VTT) e deixar só texto"""
    if not os.path.exists(caminho_vtt):
        return ""
    with open(caminho_vtt, 'r', encoding='utf-8') as f:
        linhas = f.readlines()
    
    texto_limpo = []
    for linha in linhas:
        # Remove timestamps, tags e metadados do arquivo VTT
        if '-->' not in linha and not linha.strip().isdigit() and 'WEBVTT' not in linha:
            # Remove tags HTML tipo <c>
            linha = re.sub(r'<[^>]*>', '', linha)
            if linha.strip():
                texto_limpo.append(linha.strip())
    
    # Remove duplicatas consecutivas (comum em legendas automáticas)
    resultado = []
    if texto_limpo:
        resultado.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i] != texto_limpo[i-1]:
                resultado.append(texto_limpo[i])
                
    return " ".join(resultado)

def minerar_com_yt_dlp():
    print("🚀 Iniciando OPERAÇÃO DE GUERRA: Mineração via yt-dlp...")
    
    try:
        df = pd.read_csv(ARQUIVO_CSV, quotechar='"', skipinitialspace=True)
        df.columns = [c.replace('"', '').strip() for c in df.columns]
    except Exception as e:
        print(f"❌ Erro ao ler CSV: {e}")
        return

    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)

    playlists = df.groupby('Playlist')
    total_videos = len(df)
    videos_processados = 0

    for nome_playlist, group in playlists:
        nome_limpo = str(nome_playlist).replace("/", "-").strip()
        caminho_txt = os.path.join(OUTPUT_FOLDER, f"{nome_limpo}.txt")
        print(f"\n📂 Minerando Playlist: {nome_limpo}")

        with open(caminho_txt, "a", encoding="utf-8") as f_final:
            for index, row in group.iterrows():
                v_link = row['Link']
                titulo = str(row['Título do Vídeo']).replace('"', '').strip()
                videos_processados += 1
                
                print(f"🎬 Tentando: {titulo[:40]}...")

                try:
                    # Comando para baixar APENAS a legenda automática em PT
                    # --skip-download: não baixa o vídeo, só a legenda
                    # --write-auto-subs: baixa a automática
                    cmd = [
                        'yt-dlp',
                        '--skip-download',
                        '--write-auto-sub',
                        '--sub-lang', 'pt',
                        '--output', 'temp_legenda',
                        v_link
                    ]
                    
                    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    
                    # O yt-dlp salva como temp_legenda.pt.vtt
                    caminho_vtt = 'temp_legenda.pt.vtt'
                    
                    if os.path.exists(caminho_vtt):
                        texto = limpar_vtt(caminho_vtt)
                        
                        f_final.write(f"\n--- VÍDEO: {titulo} ---\n")
                        f_final.write(f"LINK: {v_link}\n")
                        f_final.write(f"CONTEÚDO:\n{texto}\n")
                        f_final.write("-" * 30 + "\n")
                        
                        print(f"  ✅ [{videos_processados}/{total_videos}] Sucesso!")
                        os.remove(caminho_vtt) # Limpa o lixo
                    else:
                        print(f"  ❌ [{videos_processados}/{total_videos}] YouTube não gerou legenda para este vídeo.")

                    time.sleep(3) # Pausa estratégica para manter o IP limpo

                except Exception as e:
                    print(f"  ❌ Erro crítico no vídeo: {titulo[:30]}")
                    time.sleep(5)

    print(f"\n🏆 MISSÃO CUMPRIDA! Verifique a pasta '{OUTPUT_FOLDER}'.")

if __name__ == "__main__":
    minerar_com_yt_dlp()