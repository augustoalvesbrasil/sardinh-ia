import os
import time
import subprocess
import re
import json
import pandas as pd

# --- CONFIGURAÇÕES ---
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
DB_FILE = 'base_conhecimento_auvp.csv'
OUTPUT_FOLDER = 'cerebro_auvp_playlists'

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8') as f:
        linhas = f.readlines()
    texto_limpo = []
    for linha in linhas:
        if '-->' not in linha and not linha.strip().isdigit() and 'WEBVTT' not in linha:
            linha = re.sub(r'<[^>]*>', '', linha)
            if linha.strip(): texto_limpo.append(linha.strip())
    resultado = []
    if texto_limpo:
        resultado.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i] != texto_limpo[i-1]:
                resultado.append(texto_limpo[i])
    return " ".join(resultado)

def carregar_banco():
    if os.path.exists(DB_FILE):
        return pd.read_csv(DB_FILE)
    return pd.DataFrame(columns=['ID', 'Link', 'Titulo', 'Playlist', 'Status'])

def minerador_v5_the_tank():
    print("🚀 Sardinha Engine v5: Iniciando Operação Tank...")
    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)
    
    df_db = carregar_banco()

    # 1. Obter lista de playlists usando um método mais robusto
    print("📡 Mapeando playlists do canal...")
    cmd_playlists = [
        'yt-dlp', '--flat-playlist', '--get-id', '--get-title', 
        '--ignore-errors', URL_CANAL
    ]
    
    result = subprocess.run(cmd_playlists, capture_output=True, text=True)
    lines = result.stdout.strip().split('\n')
    
    # Organiza em pares [Titulo, ID]
    playlists_encontradas = []
    for i in range(0, len(lines), 2):
        if i+1 < len(lines):
            playlists_encontradas.append({'title': lines[i], 'id': lines[i+1]})

    if not playlists_encontradas:
        print("❌ Nenhuma playlist encontrada. Tentando modo fallback (URL direta)...")
        # Se falhar, o YouTube pode estar bloqueando a página de playlists. 
        # Vamos tentar o canal principal.
        return

    print(f"✅ {len(playlists_encontradas)} Playlists identificadas.")

    for p in playlists_encontradas:
        p_name = p['title'].replace("/", "-").strip()
        p_id = p['id']
        caminho_txt = os.path.join(OUTPUT_FOLDER, f"{p_name}.txt")

        print(f"\n📂 Minerando: {p_name}")

        # 2. Obter vídeos da playlist (filtrando privados)
        cmd_videos = [
            'yt-dlp', '--flat-playlist', '--dump-single-json', 
            '--ignore-errors', f'https://www.youtube.com/playlist?list={p_id}'
        ]
        v_result = subprocess.run(cmd_videos, capture_output=True, text=True)
        
        try:
            videos = json.loads(v_result.stdout).get('entries', [])
        except:
            print(f"  ⚠️ Erro ao ler vídeos da playlist {p_name}. Pulando...")
            continue

        for v in videos:
            if not v: continue
            v_id = v.get('id')
            v_title = v.get('title')
            v_link = f"https://www.youtube.com/watch?v={v_id}"

            if v_title in ['[Private video]', '[Deleted video]', None]:
                continue

            # Check de Cache
            if v_id in df_db['ID'].values:
                print(f"  ⏭️ Já processado: {v_title[:30]}...")
                continue

            print(f"  🎬 Extraindo: {v_title[:40]}...")

            try:
                temp_out = f"temp_{v_id}"
                # Baixa apenas se houver transcrição disponível
                subprocess.run([
                    'yt-dlp', '--skip-download', '--write-auto-sub', 
                    '--sub-lang', 'pt', '--output', temp_out, v_link
                ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

                vtt_file = f"{temp_out}.pt.vtt"
                if os.path.exists(vtt_file):
                    texto = limpar_vtt(vtt_file)
                    if len(texto) > 100:
                        with open(caminho_txt, "a", encoding="utf-8") as f:
                            f.write(f"\n--- VÍDEO: {v_title} ---\nLINK: {v_link}\nCONTEÚDO:\n{texto}\n" + "-"*30 + "\n")
                        
                        # Salva no banco
                        nova_linha = {'ID': v_id, 'Link': v_link, 'Titulo': v_title, 'Playlist': p_name, 'Status': 'Sucesso'}
                        df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                        df_db.to_csv(DB_FILE, index=False)
                        print(f"    ✅ Sucesso!")
                    
                    os.remove(vtt_file)
                else:
                    print(f"    ❌ Legenda não disponível.")
                
                time.sleep(4) # Pausa estratégica

            except Exception as e:
                print(f"    ❌ Erro: {e}")

    print(f"\n🏆 MISSÃO CUMPRIDA! CSV e Playlists atualizados.")

if __name__ == "__main__":
    minerador_v5_the_tank()