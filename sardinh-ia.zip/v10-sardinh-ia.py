import os
import time
import subprocess
import re
import io
import json
import pandas as pd
from datetime import datetime
from fpdf import FPDF
from fpdf.enums import XPos, YPos

# Bibliotecas Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload

# ==========================================
# --- CONFIGURAÇÕES ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

CANAL_URL = 'https://www.youtube.com/@InvestidorSardinha'
ABAS_VARRER = [
    {"tipo": "Curso", "url": f"{CANAL_URL}/courses"},
    {"tipo": "Podcast", "url": f"{CANAL_URL}/podcasts"},
    {"tipo": "Stream", "url": f"{CANAL_URL}/streams"},
    {"tipo": "Short", "url": f"{CANAL_URL}/shorts"},
    {"tipo": "Playlist", "url": f"{CANAL_URL}/playlists"},
    {"tipo": "Video", "url": f"{CANAL_URL}/videos"} # Por último para catch-all
]

LOCAL_BRAIN = 'cerebro_local'
LOCAL_GESTÃO = 'gestao_local'
DB_FILE = os.path.join(LOCAL_GESTÃO, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(LOCAL_GESTÃO, 'base_conhecimento_auvp.xlsx')
MAX_WORDS = 400000 

# ==========================================
# --- LIMPEZA DE DADOS (ANTI-LIXO) ---
# ==========================================

def remover_duplicatas_legenda(texto):
    """Remove o efeito de 'texto rolante' que gera repetições absurdas"""
    palavras = texto.split()
    if not palavras: return ""
    res = []
    if palavras:
        res.append(palavras[0])
        for i in range(1, len(palavras)):
            # Se a palavra for igual à anterior, pula (muito comum em legendas auto)
            if palavras[i].lower() != palavras[i-1].lower():
                res.append(palavras[i])
    return " ".join(res)

def limpar_vtt_v4(caminho_vtt):
    """Lógica da v4 refinada com anti-repetição"""
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    
    texto_limpo = []
    for l in linhas:
        if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l:
            limpa = re.sub(r'<[^>]*>', '', l).strip()
            if limpa: texto_limpo.append(limpa)
    
    # Processa remoção de repetições
    bruto = " ".join(texto_limpo).replace("&nbsp;", " ")
    return remover_duplicatas_legenda(bruto)

def formatar_data(data_str):
    if not data_str or data_str == 'NA': return "01/01/2000"
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return str(data_str)

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- PDF DESIGNER ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('helvetica', 'B', 12)
        self.set_text_color(255, 140, 0)
        self.cell(0, 10, 'CONHECIMENTO AUVP', 0, align='C', new_x=XPos.LMARGIN, new_y=YPos.NEXT)

def gerar_pdf_in_memory(blocos):
    pdf = AUVP_PDF()
    pdf.set_margins(15, 15, 15)
    pdf.add_page()
    largura = pdf.epw
    for bloco in blocos:
        try: msg = bloco.encode('latin-1', 'replace').decode('latin-1')
        except: msg = bloco.encode('ascii', 'replace').decode('ascii')
        if "TITULO:" in msg:
            pdf.ln(5); pdf.set_font('helvetica', 'B', 11); pdf.set_text_color(0, 0, 0)
            pdf.multi_cell(largura, 7, msg, border='B', align='L'); pdf.ln(2)
        else:
            pdf.set_font('helvetica', size=10); pdf.set_text_color(40, 40, 40)
            pdf.multi_cell(largura, 5, msg, align='L')
    return pdf.output()

# ==========================================
# --- MOTOR POR ETAPAS ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
        creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def sardinha_engine_v34():
    print("\n" + "█"*80)
    print("🚀 SARDINHA ENGINE V34: THE INDUSTRIAL HUB")
    print("█"*80 + "\n")
    
    if not os.path.exists(LOCAL_BRAIN): os.makedirs(LOCAL_BRAIN)
    if not os.path.exists(LOCAL_GESTÃO): os.makedirs(LOCAL_GESTÃO)

    # Banco de Dados de IDs para Deduplicação
    ids_mapeados = set()
    all_videos_manifesto = []

    # ETAPA 1: MAPEAMENTO POR CATEGORIAS
    for aba in ABAS_VARRER:
        tipo = aba['tipo']
        print(f"📡 Varrendo {tipo} | ", end="", flush=True)
        
        # Mapeamento v4/v18 core
        cmd = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s|||%(playlist_title)s', aba['url']]
        raw = executar_comando(cmd)
        listagem = [line for line in raw.split('\n') if '|||' in line]
        
        count = 0
        for line in listagem:
            parts = line.split('|||')
            v_id = parts[0]
            if v_id not in ids_mapeados:
                all_videos_manifesto.append({
                    'ID': v_id, 'Data': formatar_data(parts[1]), 'Views': parts[2],
                    'Titulo': parts[3].strip(), 'Playlist': parts[4] if parts[4] and parts[4] != "NA" else "Geral",
                    'Tipo': tipo, 'Link': f"https://www.youtube.com/watch?v={v_id}", 'Status': 'Pendente'
                })
                ids_mapeados.add(v_id)
                count += 1
        print(f"{count} novos encontrados.")

    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data', 'Link', 'Titulo', 'Tipo', 'Playlist', 'Views', 'Status'])
    total_trabalho = len(all_videos_manifesto)

    # ETAPA 2: MINERAÇÃO LOCAL (LOGICA V4)
    print(f"\n🎬 Iniciando Mineração Local de {total_trabalho} vídeos...")
    for idx, video in enumerate(all_videos_manifesto, 1):
        v_id, v_title, v_link = video['ID'], video['Titulo'], video['Link']
        v_playlist_sanitizada = re.sub(r'[<>:\"/\\|?*]', '', video['Playlist']).strip()
        caminho_local_txt = os.path.join(LOCAL_BRAIN, f"Base_{v_playlist_sanitizada}.txt")
        prefix = f"[{idx}/{total_trabalho}]"

        # Check de existência no TXT (Exigência 6)
        if os.path.exists(caminho_local_txt):
            with open(caminho_local_txt, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if v_link in f.read():
                    print(f"{prefix} ⏭️  Pular: {v_title[:45]} (OK)")
                    continue

        print(f"{prefix} 🎬 Extraindo: {v_title[:45]}...")
        try:
            temp_out = f"temp_{v_id}"
            # COMANDO V4 QUE FUNCIONA
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt.*', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Busca vtt (independente se é pt, pt-BR, etc)
            vtt = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            
            if vtt:
                texto = limpar_vtt_profissional(vtt[0])
                if len(texto) > 150:
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\nTITULO: {v_title}\nDATA: {video['Data']}\nVIEWS: {video['Views']}\nLINK: {v_link}\nTIPO: {video['Tipo']}\nCONTEUDO:\n{texto}\n" + "="*50 + "\n")
                    
                    # Atualiza Planilha Local (Exigência 2)
                    video['Status'] = 'Sucesso'
                    df_db = pd.concat([df_db, pd.DataFrame([video])], ignore_index=True).drop_duplicates(subset=['ID'])
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                    print(f"      ✅ Sucesso!")
                os.remove(vtt[0])
            else:
                print(f"      ❌ YouTube bloqueou ou sem transcrição.")
            time.sleep(2)
        except Exception as e: print(f"      ❌ Erro: {e}")

    # ETAPA 3: FINALIZAÇÃO E SINCRONIA (SÓ NO FINAL - Exigência 7, 8)
    print("\n📊 Gerando Excel e Sincronizando com o Drive...")
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    
    service = get_drive_service()
    for arq_txt in os.listdir(LOCAL_BRAIN):
        if arq_txt.endswith(".txt"):
            nome_base = arq_txt.replace(".txt", "")
            with open(os.path.join(LOCAL_BRAIN, arq_txt), 'r', encoding='utf-8-sig', errors='replace') as f:
                videos_lote = f.read().split("="*50)
            
            lote_pdf = []; words = 0; parte = 1
            for v_txt in videos_lote:
                if not v_txt.strip(): continue
                w_count = len(v_txt.split())
                if words + w_count > MAX_WORDS:
                    enviar_lote_drive(service, f"{nome_base}_Parte_{parte}.pdf", lote_pdf)
                    lote_pdf = [v_txt]; words = w_count; parte += 1
                else:
                    lote_pdf.append(v_txt + "\n" + "="*50)
                    words += w_count
            if lote_pdf:
                nome_final = f"{nome_base}_Parte_{parte}.pdf" if parte > 1 else f"{nome_base}.pdf"
                enviar_lote_drive(service, nome_final, lote_pdf)

    # Planilhas
    media_csv = MediaIoBaseUpload(io.BytesIO(df_db.to_csv(index=False, encoding='utf-8-sig').encode('utf-8-sig')), mimetype='text/csv')
    service.files().create(body={'name': 'base_conhecimento_auvp.csv', 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media_csv).execute()

    print(f"\n🏆 PROCESSO CONCLUÍDO! Verifique o Drive.")

def enviar_lote_drive(service, nome, blocos):
    print(f"   ⬆️ Enviando PDF: {nome}...")
    pdf_bytes = gerar_pdf_in_memory(blocos)
    media = MediaIoBaseUpload(io.BytesIO(pdf_bytes), mimetype='application/pdf', resumable=True)
    q = f"name = '{nome}' and '{FOLDER_BRAIN_DRIVE}' in parents and trashed = false"
    res = service.files().list(q=q).execute().get('files', [])
    if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
    else: service.files().create(body={'name': nome, 'parents': [FOLDER_BRAIN_DRIVE]}, media_body=media).execute()

if __name__ == "__main__":
    sardinha_engine_v34()