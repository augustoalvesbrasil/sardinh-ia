import os
import time
import subprocess
import re
import pandas as pd
from datetime import datetime

# Bibliotecas Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# --- CONFIGURAÇÕES DRIVE ---
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   # Pasta TXTs
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  # Pasta Planilhas
SCOPES = ['https://www.googleapis.com/auth/drive']

# --- CONFIGURAÇÕES LOCAIS (IGUAL V4) ---
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
OUTPUT_FOLDER = 'cerebro_local'
GESTÃO_FOLDER = 'gestao_local'
DB_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.xlsx')

def sanitizar_nome(nome):
    if not nome: return "Sem_Nome"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str in ['NA', 'None']: return ""
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    texto_limpo = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
    res = []
    if texto_limpo:
        res.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i].lower() != texto_limpo[i-1].lower(): res.append(texto_limpo[i])
    return " ".join(res).strip()

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- LOGICA DE UPLOAD (EXCLUSIVA NO FINAL) ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def sincronizar_com_drive():
    print("\n☁️  Iniciando Sincronização Final com Google Drive...")
    service = get_drive_service()

    # Sincroniza TXTs (Pasta Cérebro)
    for arq in os.listdir(OUTPUT_FOLDER):
        if arq.endswith(".txt"):
            caminho = os.path.join(OUTPUT_FOLDER, arq)
            query = f"name = '{arq}' and '{FOLDER_BRAIN_DRIVE}' in parents and trashed = false"
            res = service.files().list(q=query).execute().get('files', [])
            media = MediaFileUpload(caminho, resumable=True)
            if res:
                service.files().update(fileId=res[0]['id'], media_body=media).execute()
            else:
                service.files().create(body={'name': arq, 'parents': [FOLDER_BRAIN_DRIVE]}, media_body=media).execute()
            print(f"   ✅ {arq} enviado.")

    # Sincroniza Planilhas (Pasta Gestão)
    for arq in [DB_FILE, EXCEL_FILE]:
        if os.path.exists(arq):
            nome = os.path.basename(arq)
            query = f"name = '{nome}' and '{FOLDER_SHEETS_DRIVE}' in parents and trashed = false"
            res = service.files().list(q=query).execute().get('files', [])
            media = MediaFileUpload(arq, resumable=True)
            if res:
                service.files().update(fileId=res[0]['id'], media_body=media).execute()
            else:
                service.files().create(body={'name': nome, 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media).execute()
            print(f"   ✅ {nome} enviado.")

# ==========================================
# --- MOTOR PRINCIPAL (IDENTICO V4) ---
# ==========================================

def minerador_v18_final():
    print("\n" + "="*60)
    print("🚀 SARDINHA ENGINE V18: THE MASTERPIECE (v4 Logic + Final Sync)")
    print("="*60 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)
    if not os.path.exists(GESTÃO_FOLDER): os.makedirs(GESTÃO_FOLDER)

    # Carrega banco
    if os.path.exists(DB_FILE):
        df_db = pd.read_csv(DB_FILE, dtype=str)
    else:
        df_db = pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    print("📡 Localizando playlists...")
    stdout_p = executar_comando(['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL])
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines):
            playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    all_videos = []
    print(f"✅ {len(playlists_info)} Playlists encontradas. Cruzando dados...")
    
    for p in playlists_info:
        print(f"   📂 Mapeando: {p['title'][:40]}...")
        stdout_v = executar_comando(['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', f"https://www.youtube.com/playlist?list={p['id']}"])
        for line in stdout_v.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_videos.append({'id': parts[0], 'date': formatar_data(parts[1]), 'views': parts[2], 'title': parts[3], 'playlist': p['title']})

    total = len(all_videos)
    print(f"\n📊 Iniciando Mineração Local de {total} vídeos...")

    for idx, video in enumerate(all_videos, 1):
        v_id, v_title, v_link = video['id'], video['title'], f"https://www.youtube.com/watch?v={video['id']}"
        nome_txt = f"{sanitizar_nome(video['playlist'])}.txt"
        caminho_local = os.path.join(OUTPUT_FOLDER, nome_txt)
        prefix = f"[{idx}/{total}]"

        if v_title in ['[Private video]', '[Deleted video]']: continue

        # Lógica v4: Check se já existe no arquivo físico local
        ja_no_txt = False
        if os.path.exists(caminho_local):
            with open(caminho_local, 'r', encoding='utf-8-sig') as f:
                if v_link in f.read(): ja_no_txt = True

        if ja_no_txt:
            print(f"{prefix} ⏭️  Pular: {v_title[:45]} (OK)")
            continue

        print(f"{prefix} 🎬 Minerando: {v_title[:45]}...")
        
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt.*', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            # Acha o VTT gerado (independente de ser pt ou pt-br)
            vtt_files = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            
            if vtt_files:
                texto = limpar_vtt(vtt_files[0])
                if len(texto) > 150:
                    with open(caminho_local, "a", encoding="utf-8-sig") as f:
                        f.write(f"\n{'='*60}\nTITULO: {v_title}\nDATA: {video['date']}\nVIEWS: {video['views']}\nLINK: {v_link}\n{'-'*60}\nCONTEÚDO:\n{texto}\n{'='*60}\n")
                    
                    nova_linha = {'ID': v_id, 'Data_Pub': video['date'], 'Link': v_link, 'Titulo': v_title, 'Playlist': video['playlist'], 'Views': video['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8')
                    print(f"      ✅ Sucesso Local!")
                
                for f in vtt_files: os.remove(f)
            else:
                print(f"      ❌ YouTube sem legenda.")
            time.sleep(3) # Segurança

        except Exception as e:
            print(f"      ❌ Erro: {e}")

    # GERA EXCEL LOCAL ANTES DE SUBIR
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)

    # FINALIZAÇÃO: SUBIR TUDO PRO DRIVE
    sincronizar_com_drive()
    print("\n🏆 MISSÃO CUMPRIDA! Tudo em ordem localmente e na nuvem.")

if __name__ == "__main__":
    minerador_v18_final()