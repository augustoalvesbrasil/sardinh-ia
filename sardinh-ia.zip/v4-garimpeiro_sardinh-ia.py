import os
import time
import subprocess
import re
import pandas as pd
from datetime import datetime

# --- CONFIGURAÇÕES ---
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
DB_FILE = 'base_conhecimento_auvp.csv'
EXCEL_FILE = 'base_conhecimento_auvp.xlsx'
OUTPUT_FOLDER = 'cerebro_local'

def sanitizar_nome(nome):
    if not nome: return "Sem_Nome"
    nome_limpo = re.sub(r'[<>:"/\\|?*]', '', str(nome))
    return nome_limpo.strip()

def formatar_data(data_str):
    """Converte YYYYMMDD ou NA para DD/MM/YYYY"""
    if not data_str or data_str == 'NA' or data_str == 'None':
        return ""
    try:
        return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except:
        return data_str

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    try:
        with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
            linhas = f.readlines()
        texto_limpo = []
        for linha in linhas:
            if '-->' not in linha and not linha.strip().isdigit() and 'WEBVTT' not in linha:
                linha = re.sub(r'<[^>]*>', '', linha)
                if linha.strip(): texto_limpo.append(linha.strip())
        resultado = []
        if texto_limpo:
            resultado.append(texto_limpo[0])
            for i in range(1, len(texto_limpo)):
                if texto_limpo[i] != texto_limpo[i-1]:
                    resultado.append(texto_limpo[i])
        return " ".join(resultado)
    except: return ""

def carregar_banco():
    if os.path.exists(DB_FILE):
        try:
            df = pd.read_csv(DB_FILE, encoding='utf-8')
            # Garante que colunas novas existam no arquivo antigo
            for col in ['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status']:
                if col not in df.columns: df[col] = ""
            return df
        except: return pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])
    return pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

def executar_comando(cmd):
    try:
        result = subprocess.run(cmd, capture_output=True, text=False, check=False)
        return result.stdout.decode('utf-8', errors='replace')
    except Exception as e:
        return ""

def minerador_v8_1_chronos():
    print("\n" + "="*60)
    print("🚀 SARDINHA ENGINE V8.1: THE CHRONOS (Date & View Fix)")
    print("="*60 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)
    df_db = carregar_banco()

    # 1. Mapeamento de Playlists
    print("📡 Localizando playlists...")
    cmd_p = ['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL]
    stdout_p = executar_comando(cmd_p)
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines):
            playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    if not playlists_info:
        print("❌ Canal não encontrado.")
        return

    # 2. Varredura Total do Canal
    all_videos = []
    print(f"✅ {len(playlists_info)} Playlists encontradas. Cruzando dados...")
    
    for p in playlists_info:
        print(f"   📂 Mapeando: {p['title'][:40]}...")
        # Template com separador especial e sem limite de busca
        cmd_v = [
            'yt-dlp', '--flat-playlist', '--ignore-errors',
            '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s',
            f"https://www.youtube.com/playlist?list={p['id']}"
        ]
        stdout_v = executar_comando(cmd_v)
        v_lines = [l.strip() for l in stdout_v.split('\n') if l.strip()]
        
        for line in v_lines:
            parts = line.split('|||')
            if len(parts) >= 4:
                v_id, v_raw_date, v_raw_views, v_title = parts[0], parts[1], parts[2], parts[3]
                all_videos.append({
                    'id': v_id, 'title': v_title, 
                    'date': formatar_data(v_raw_date), 
                    'views': int(v_raw_views) if v_raw_views.isdigit() else 0,
                    'playlist': p['title']
                })

    total_canal = len(all_videos)
    print(f"\n📊 Total de vídeos mapeados: {total_canal}")
    print("-" * 40)

    # 3. Mineração e Reparação de Dados
    sucessos = 0
    pulos = 0

    for idx, video in enumerate(all_videos, 1):
        v_id = video['id']
        v_title = video['title']
        v_playlist_limpa = sanitizar_nome(video['playlist'])
        v_link = f"https://www.youtube.com/watch?v={v_id}"
        caminho_txt = os.path.join(OUTPUT_FOLDER, f"{v_playlist_limpa}.txt")
        prefix = f"[{idx}/{total_canal}]"

        # Lógica de Pulo ou Reparação
        if v_id in df_db['ID'].values:
            idx_db = df_db[df_db['ID'] == v_id].index[0]
            # Se já existe mas está sem data/views, vamos preencher!
            if pd.isna(df_db.at[idx_db, 'Data_Pub']) or df_db.at[idx_db, 'Data_Pub'] == "":
                df_db.at[idx_db, 'Data_Pub'] = video['date']
                df_db.at[idx_db, 'Views'] = video['views']
                df_db.to_csv(DB_FILE, index=False, encoding='utf-8')
                print(f"{prefix} 🛠️  Reparado (Metadados): {v_title[:40]}...")
            else:
                print(f"{prefix} ⏭️  Já minerado: {v_title[:40]}...")
            
            pulos += 1
            continue

        print(f"{prefix} 🎬 Minerando: {v_title[:45]}...")
        
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run([
                'yt-dlp', '--skip-download', '--write-auto-sub', 
                '--sub-lang', 'pt', '--output', temp_out, v_link
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            vtt_file = f"{temp_out}.pt.vtt"
            if os.path.exists(vtt_file):
                texto = limpar_vtt(vtt_file)
                if len(texto) > 150:
                    with open(caminho_txt, "a", encoding="utf-8") as f:
                        f.write(f"\n{'='*60}\nTITULO: {v_title}\nDATA: {video['date']}\nVIEWS: {video['views']}\nLINK: {v_link}\n{'-'*60}\nCONTEÚDO:\n{texto}\n{'='*60}\n")
                    
                    nova_linha = {
                        'ID': v_id, 'Data_Pub': video['date'], 'Link': v_link, 
                        'Titulo': v_title, 'Playlist': video['playlist'], 
                        'Views': video['views'], 'Status': 'Sucesso'
                    }
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8')
                    sucessos += 1
                    print(f"      ✅ Sucesso!")
                
                if os.path.exists(vtt_file): os.remove(vtt_file)
            else:
                print(f"      ❌ Sem transcrição.")
            
            time.sleep(2)

        except Exception as e:
            print(f"      ❌ Erro: {e}")

    # 4. Finalização Excel Premium
    print("\n📊 Convertendo para Excel...")
    try:
        # Garante que Views seja tratado como número no Excel
        df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
        df_db.to_excel(EXCEL_FILE, index=False)
        print(f"✅ Excel finalizado: {EXCEL_FILE}")
    except Exception as e:
        print(f"❌ Erro no Excel: {e}")

    print(f"\n🏆 PROCESSO FINALIZADO!")
    print(f"📈 Total no Banco: {len(df_db)}")
    print("="*60)

if __name__ == "__main__":
    minerador_v8_1_chronos()