import os
import time
import subprocess
import re
import pandas as pd
from datetime import datetime
from google.cloud import storage # <--- Importação para Nuvem

# --- CONFIGURAÇÕES DE NUVEM ---
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "google_key.json" # Sua chave JSON aqui
BUCKET_NAME = "cerebro-sardinha-dados" # Nome do seu Bucket no Google Cloud

# --- CONFIGURAÇÕES LOCAIS ---
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
DB_FILE = 'base_conhecimento_auvp.csv'
EXCEL_FILE = 'base_conhecimento_auvp.xlsx'
OUTPUT_FOLDER = 'cerebro_auvp_playlists'

def upload_para_gcs(arquivo_local, nome_na_nuvem):
    """Sincroniza o arquivo TXT com o Bucket do Google Cloud"""
    try:
        client = storage.Client()
        bucket = client.bucket(BUCKET_NAME)
        blob = bucket.blob(f"conhecimento/{nome_na_nuvem}")
        blob.upload_from_filename(arquivo_local)
        return True
    except Exception as e:
        print(f"      ☁️ Erro no upload Cloud: {e}")
        return False

def sanitizar_nome(nome):
    nome_limpo = re.sub(r'[<>:"/\\|?*]', '', str(nome))
    return nome_limpo.strip()

def formatar_data(data_str):
    if not data_str or data_str in ['NA', 'None']: return ""
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    try:
        with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
            linhas = f.readlines()
        texto_limpo = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
        res = []
        if texto_limpo:
            res.append(texto_limpo[0])
            for i in range(1, len(texto_limpo)):
                if texto_limpo[i] != texto_limpo[i-1]: res.append(texto_limpo[i])
        return " ".join(res)
    except: return ""

def carregar_banco():
    if os.path.exists(DB_FILE):
        try: return pd.read_csv(DB_FILE, encoding='utf-8', dtype=str)
        except: return pd.read_csv(DB_FILE, encoding='latin-1', dtype=str)
    return pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

def executar_comando(cmd):
    try:
        result = subprocess.run(cmd, capture_output=True, text=False, check=False)
        return result.stdout.decode('utf-8', errors='replace')
    except: return ""

def sardinha_enterprise_v9():
    print("\n" + "="*60)
    print("🚀 SARDINHA ENGINE V9: ENTERPRISE SYNC (Local + Cloud)")
    print("="*60 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)
    df_db = carregar_banco()

    # 1. Mapeamento das Playlists
    print("📡 Localizando playlists...")
    cmd_p = ['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL]
    stdout_p = executar_comando(cmd_p)
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines):
            playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    if not playlists_info:
        print("❌ Falha crítica: Canal inacessível.")
        return

    # 2. Varredura Total do Canal
    all_videos = []
    print(f"✅ {len(playlists_info)} Playlists mapeadas. Extraindo metadados...")
    
    for p in playlists_info:
        print(f"   📂 Mapeando: {p['title'][:40]}...")
        cmd_v = ['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', f"https://www.youtube.com/playlist?list={p['id']}"]
        stdout_v = executar_comando(cmd_v)
        v_lines = [l.strip() for l in stdout_v.split('\n') if l.strip()]
        for line in v_lines:
            parts = line.split('|||')
            if len(parts) >= 4:
                all_videos.append({'id': parts[0], 'title': parts[3], 'date': formatar_data(parts[1]), 'views': parts[2], 'playlist': p['title']})

    total_canal = len(all_videos)
    print(f"\n📊 Total de vídeos detectados: {total_canal}")
    print("-" * 40)

    # 3. Mineração e Sincronização em Nuvem
    sucessos = 0
    pulos = 0

    for idx, video in enumerate(all_videos, 1):
        v_id = video['id']
        v_title = video['title']
        v_playlist_limpa = sanitizar_nome(video['playlist'])
        v_link = f"https://www.youtube.com/watch?v={v_id}"
        caminho_local_txt = os.path.join(OUTPUT_FOLDER, f"{v_playlist_limpa}.txt")
        prefix = f"[{idx}/{total_canal}]"

        # Pulo se já tiver Sucesso no CSV
        if v_id in df_db['ID'].values:
            idx_db = df_db[df_db['ID'] == v_id].index[0]
            if df_db.at[idx_db, 'Status'] == 'Sucesso':
                print(f"{prefix} ⏭️  Já minerado: {v_title[:40]}...")
                pulos += 1
                continue

        print(f"{prefix} 🎬 Minerando: {v_title[:45]}...")
        
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            vtt_file = f"{temp_out}.pt.vtt"
            if os.path.exists(vtt_file):
                texto = limpar_vtt(vtt_file)
                if len(texto) > 150:
                    # Salva no arquivo Local TXT
                    with open(caminho_local_txt, "a", encoding="utf-8") as f:
                        f.write(f"\n{'='*60}\nTITULO: {v_title}\nDATA: {video['date']}\nVIEWS: {video['views']}\nLINK: {v_link}\n{'-'*60}\nCONTEÚDO:\n{texto}\n{'='*60}\n")
                    
                    # 🚀 SINCRONIZAÇÃO COM A NUVEM GOOGLE
                    print(f"      ☁️ Sincronizando playlist com Vertex AI...")
                    upload_para_gcs(caminho_local_txt, f"{v_playlist_limpa}.txt")
                    
                    # Atualiza o CSV
                    nova_linha = {'ID': v_id, 'Data_Pub': video['date'], 'Link': v_link, 'Titulo': v_title, 'Playlist': video['playlist'], 'Views': video['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8')
                    sucessos += 1
                    print(f"      ✅ Sucesso Total!")
                
                if os.path.exists(vtt_file): os.remove(vtt_file)
            else:
                print(f"      ❌ YouTube sem legenda.")
            
            time.sleep(1.5)

        except Exception as e:
            print(f"      ❌ Erro inesperado: {e}")

    # 4. Finalização dos Bancos de Dados
    print("\n📊 Finalizando Planilha Excel Analítica...")
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    
    print("\n" + "="*60)
    print(f"🏆 SISTEMA SINCRONIZADO!")
    print(f"📄 Excel Local: {EXCEL_FILE}")
    print(f"☁️ Google Cloud Storage: {BUCKET_NAME}")
    print("="*60)

if __name__ == "__main__":
    sardinha_enterprise_v9()