import os
import requests
from googleapiclient.discovery import build

# --- CONFIGURAÇÃO (CHAVE INSERIDA) ---
# Chave de API: AIzaSyDv9z1n_7HrA0IzYFzBldGLv_yx61QR9Uo
YOUTUBE_API_KEY = "AIzaSyDv9z1n_7HrA0IzYFzBldGLv_yx61QR9Uo" 

# ID do Canal do Investidor Sardinha (Raul Sena)
CHANNEL_ID = "UCM3vJxmuJJkk1r0yzFI9eZg"

# URL base para montar o link completo do vídeo
YOUTUBE_BASE_URL = "https://www.youtube.com/watch?v="

def get_channel_uploads_playlist_id(youtube):
    """Obtém o ID da playlist 'Uploads' de um canal."""
    response = youtube.channels().list(
        part="contentDetails",
        id=CHANNEL_ID
    ).execute()
    
    # CORREÇÃO DEFINITIVA: Usamos o índice  para acessar o primeiro (e único) item da lista 'items'.
    # Isso resolve o erro "list indices must be integers or slices, not str"
    return response['items']['relatedPlaylists']['uploads']

def get_all_playlist_items(youtube, playlist_id):
    """Coleta todos os IDs e detalhes de vídeos de uma playlist, tratando a paginação."""
    
    all_video_details = list()
    
    request = youtube.playlistItems().list(
        part="snippet,contentDetails",
        playlistId=playlist_id,
        maxResults=50  # Máximo por página
    )
    
    while request:
        try:
            response = request.execute()
        except Exception as e:
            # Captura falhas de cota ou rede durante a paginação
            print(f"Aviso: Falha na paginação (cota ou rede). Coletando vídeos até o momento. Detalhes: {e}")
            break

        for item in response['items']:
            # resourceId é o campo mais confiável para o ID do vídeo
            video_id = item['snippet']['resourceId']['videoId']
            title = item['snippet']['title']
            
            all_video_details.append({
                'id': video_id,
                'title': title,
                'url': f"{YOUTUBE_BASE_URL}{video_id}"
            })

        # Prepara a próxima página (Paginação)
        request = youtube.playlistItems().list_next(request, response)
        
    return all_video_details

def main():
    if not YOUTUBE_API_KEY or YOUTUBE_API_KEY == "SUA_CHAVE_DE_API_GERADA_NO_GOOGLE_CLOUD":
        print("ERRO DE CONFIGURAÇÃO: Chave de API ausente.")
        return

    try:
        # 1. Conecta-se ao serviço do YouTube
        youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
    except Exception as e:
        print(f"ERRO DE CONEXÃO: Não foi possível construir o serviço da API. Detalhes: {e}")
        return
        
    print(f"--- Coletando links do canal Investidor Sardinha ---")
    
    # 2. Encontra o ID da playlist de uploads do canal (COM A CORREÇÃO DE NAVEGAÇÃO)
    try:
        uploads_playlist_id = get_channel_uploads_playlist_id(youtube)
        print(f"ID da Playlist de Uploads encontrado: {uploads_playlist_id}")
    except Exception as e:
        print(f"ERRO CRÍTICO: Não foi possível obter a playlist de uploads. Detalhes: {e}")
        print("\nVerificações:")
        print("1. Cota diária excedida (volte em 24h).")
        print("2. A 'YouTube Data API v3' não está ativada no seu projeto (embora sua imagem mostre que está).")
        return

    # 3. Coleta todos os vídeos
    print("Iniciando coleta de vídeos (isso pode levar alguns minutos)...")
    all_videos = get_all_playlist_items(youtube, uploads_playlist_id)
    
    # 4. Processa e salva
    if not all_videos:
        print("Nenhum vídeo encontrado.")
        return

    print(f"\n--- {len(all_videos)} LINKS DE VÍDEOS ENCONTRADOS ---\n")
    
    links_finais = [video['url'] for video in all_videos]
        
    file_path = os.path.join(os.getcwd(), "links_investidor_sardinha.txt")
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("\n".join(links_finais))
        
    print(f"--- Processo Concluído ---")
    print(f"A lista completa de {len(all_videos)} links foi salva no arquivo: {file_path}")

if __name__ == "__main__":
    main()