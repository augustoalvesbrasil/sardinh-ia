import os
import time
import subprocess
import re
import io
import pandas as pd
from datetime import datetime
from fpdf import FPDF

# Bibliotecas Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# ==========================================
# --- CONFIGURAÇÕES DRIVE ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   # Pasta para os PDFs
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  # Pasta para Planilhas
SCOPES = ['https://www.googleapis.com/auth/drive']

# --- CONFIGURAÇÕES LOCAIS ---
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
OUTPUT_FOLDER_TXT = 'cerebro_local' 
GESTÃO_FOLDER = 'gestao_local'
DB_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.xlsx')

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    if not nome: return "Sem_Nome"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str == 'NA': return ""
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    texto_limpo = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
    res = []
    if texto_limpo:
        res.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i].lower() != texto_limpo[i-1].lower(): res.append(texto_limpo[i])
    return " ".join(res).strip()

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- LIBRARIAN: GERAÇÃO DE PDF ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, 'BASE DE CONHECIMENTO AUVP', 0, 1, 'C')
        self.ln(5)

def gerar_pdf_da_playlist(caminho_txt, nome_pdf):
    """Transforma o TXT minerado em um PDF limpo para o NotebookLM"""
    print(f"   📑 Gerando PDF: {nome_pdf}...")
    pdf = AUVP_PDF()
    pdf.add_page()
    pdf.set_font("Arial", size=10)
    
    with open(caminho_txt, 'r', encoding='utf-8-sig', errors='replace') as f:
        for linha in f:
            # Garante compatibilidade de caracteres latinos no PDF
            msg = linha.encode('latin-1', 'replace').decode('latin-1')
            if "TITULO:" in linha:
                pdf.set_font("Arial", 'B', 11)
                pdf.multi_cell(0, 8, msg)
                pdf.set_font("Arial", size=10)
            else:
                pdf.multi_cell(0, 5, msg)
    
    caminho_pdf = caminho_txt.replace(".txt", ".pdf")
    pdf.output(caminho_pdf)
    return caminho_pdf

# ==========================================
# --- DRIVE SYNC ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token: creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def sincronizar_final():
    print("\n☁️  Iniciando Sincronização Final (PDFs & Planilhas)...")
    service = get_drive_service()

    # 1. PDFs (Pasta Cérebro)
    for arq in os.listdir(OUTPUT_FOLDER_TXT):
        if arq.endswith(".txt"):
            txt_local = os.path.join(OUTPUT_FOLDER_TXT, arq)
            nome_pdf = arq.replace(".txt", ".pdf")
            pdf_local = gerar_pdf_da_playlist(txt_local, nome_pdf)
            
            # Sobe pro Drive
            media = MediaFileUpload(pdf_local, mimetype='application/pdf', resumable=True)
            q = f"name = '{nome_pdf}' and '{FOLDER_BRAIN_DRIVE}' in parents and trashed = false"
            res = service.files().list(q=q).execute().get('files', [])
            
            if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
            else: service.files().create(body={'name': nome_pdf, 'parents': [FOLDER_BRAIN_DRIVE]}, media_body=media).execute()
            
            if os.path.exists(pdf_local): os.remove(pdf_local)
            print(f"      ✅ PDF Sincronizado: {nome_pdf}")

    # 2. Planilhas (Pasta Gestão)
    for path, nome_drive in [(DB_FILE, 'base_conhecimento_auvp.csv'), (EXCEL_FILE, 'base_conhecimento_auvp.xlsx')]:
        if os.path.exists(path):
            media = MediaFileUpload(path, resumable=True)
            q = f"name = '{nome_drive}' and '{FOLDER_SHEETS_DRIVE}' in parents and trashed = false"
            res = service.files().list(q=q).execute().get('files', [])
            if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
            else: service.files().create(body={'name': nome_drive, 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media).execute()
            print(f"   📊 Planilha Sincronizada: {nome_drive}")

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_engine_v23_1():
    print("\n" + "█"*75)
    print("🚀 SARDINHA ENGINE V23.1: THE LIBRARIAN (Stable Extraction)")
    print("█"*75 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER_TXT): os.makedirs(OUTPUT_FOLDER_TXT)
    if not os.path.exists(GESTÃO_FOLDER): os.makedirs(GESTÃO_FOLDER)

    # 1. Mapeamento
    print("📡 Localizando playlists no YouTube...")
    stdout_p = executar_comando(['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL])
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines): playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    # 2. Varredura de Vídeos
    all_videos = []
    print(f"✅ {len(playlists_info)} Playlists encontradas. Cruzando dados...")
    for p in playlists_info:
        print(f"   📂 Mapeando: {p['title'][:35]}...")
        stdout_v = executar_comando(['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', f"https://www.youtube.com/playlist?list={p['id']}"])
        for line in stdout_v.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_videos.append({'id': parts[0], 'date': formatar_data(parts[1]), 'views': parts[2], 'title': parts[3], 'playlist': p['title']})

    # 3. Mineração Local
    total = len(all_videos)
    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    for idx, video in enumerate(all_videos, 1):
        # ATRIBUIÇÃO CORRIGIDA AQUI:
        current_id = video['id']
        current_title = video['title']
        current_link = f"https://www.youtube.com/watch?v={current_id}"
        
        nome_txt = f"{sanitizar_nome(video['playlist'])}.txt"
        caminho_local_txt = os.path.join(OUTPUT_FOLDER_TXT, nome_txt)
        prefix = f"[{idx}/{total}]"

        if current_title in ['[Private video]', '[Deleted video]']: continue

        # Check local TXT
        ja_existe = False
        if os.path.exists(caminho_local_txt):
            with open(caminho_local_txt, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if current_link in f.read(): ja_existe = True

        if ja_existe:
            print(f"{prefix} ⏭️  Pular: {current_title[:45]}...")
            continue

        print(f"{prefix} 🎬 Extraindo: {current_title[:45]}...")
        try:
            temp_out = f"temp_{current_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, current_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Acha o arquivo baixado
            vtt_files = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            
            if vtt_files:
                texto = limpar_vtt(vtt_files[0])
                if len(texto) > 150:
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\nTITULO: {current_title}\nDATA: {video['date']}\nVIEWS: {video['views']}\nLINK: {current_link}\nCONTEÚDO:\n{texto}\n" + "="*50 + "\n")
                    
                    nova_linha = {'ID': current_id, 'Data_Pub': video['date'], 'Link': current_link, 'Titulo': current_title, 'Playlist': video['playlist'], 'Views': video['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                    print(f"      ✅ Sucesso Local!")
                
                for f in vtt_files: os.remove(f)
            else:
                print(f"      ❌ Falha: Sem transcrição.")
            time.sleep(3)
        except Exception as e: print(f"      ❌ Erro: {e}")

    # 4. Finalização
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    sincronizar_final()
    print("\n🏆 DRIVE ATUALIZADO COM PDFs! NotebookLM pronto.")

if __name__ == "__main__":
    sardinha_engine_v23_1()