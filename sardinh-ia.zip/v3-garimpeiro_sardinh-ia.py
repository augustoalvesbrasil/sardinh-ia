import os
import time
import subprocess
import re
import json
import pandas as pd

# --- CONFIGURAÇÕES ---
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
DB_FILE = 'base_conhecimento_auvp.csv'
OUTPUT_FOLDER = 'cerebro_auvp_playlists'

def sanitizar_nome(nome):
    """Remove caracteres proibidos para nomes de arquivos no Windows/Linux/Mac"""
    # Remove: < > : " / \ | ? *
    nome_limpo = re.sub(r'[<>:"/\\|?*]', '', nome)
    return nome_limpo.strip()

def limpar_vtt(caminho_vtt):
    """Limpa o lixo das legendas e remove repetições consecutivas"""
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8') as f:
        linhas = f.readlines()
    texto_limpo = []
    for linha in linhas:
        if '-->' not in linha and not linha.strip().isdigit() and 'WEBVTT' not in linha:
            linha = re.sub(r'<[^>]*>', '', linha)
            if linha.strip(): texto_limpo.append(linha.strip())
    resultado = []
    if texto_limpo:
        resultado.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i] != texto_limpo[i-1]:
                resultado.append(texto_limpo[i])
    return " ".join(resultado)

def carregar_banco():
    if os.path.exists(DB_FILE):
        return pd.read_csv(DB_FILE)
    return pd.DataFrame(columns=['ID', 'Link', 'Titulo', 'Playlist', 'Status'])

def minerador_v6_windows_patch():
    print("\n" + "="*50)
    print("🚀 SARDINHA ENGINE V6.1: WINDOWS PATCH")
    print("="*50 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)
    df_db = carregar_banco()

    # 1. Mapeamento de Playlists
    print("📡 Mapeando estrutura de playlists...")
    cmd_playlists = ['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL]
    res_p = subprocess.run(cmd_playlists, capture_output=True, text=True)
    p_lines = res_p.stdout.strip().split('\n')
    
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines):
            playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    if not playlists_info:
        print("❌ Nenhuma playlist encontrada.")
        return

    # 2. Pré-mapeamento de todos os vídeos
    print(f"✅ {len(playlists_info)} Playlists mapeadas. Calculando total de vídeos...")
    all_videos_map = []
    for p in playlists_info:
        cmd_v = ['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', f"https://www.youtube.com/playlist?list={p['id']}"]
        res_v = subprocess.run(cmd_v, capture_output=True, text=True)
        v_lines = res_v.stdout.strip().split('\n')
        for j in range(0, len(v_lines), 2):
            if j+1 < len(v_lines):
                all_videos_map.append({'id': v_lines[j+1], 'title': v_lines[j], 'playlist': p['title']})

    total_canal = len(all_videos_map)
    print(f"📊 Total de vídeos no canal: {total_canal}")
    print("-" * 30)

    # 3. Mineração com Sanitização de Arquivos
    sucessos = 0
    pulos = 0

    for idx, video in enumerate(all_videos_map, 1):
        v_id = video['id']
        v_title = video['title']
        v_playlist_bruta = video['playlist']
        v_playlist_limpa = sanitizar_nome(v_playlist_bruta) # <--- A mágica está aqui
        v_link = f"https://www.youtube.com/watch?v={v_id}"
        
        caminho_txt = os.path.join(OUTPUT_FOLDER, f"{v_playlist_limpa}.txt")
        prefix = f"[{idx}/{total_canal}]"

        if v_title in ['[Private video]', '[Deleted video]', None]:
            pulos += 1
            continue

        # Check de Cache
        if v_id in df_db['ID'].values:
            status = df_db.loc[df_db['ID'] == v_id, 'Status'].values[0]
            if status == 'Sucesso':
                print(f"{prefix} ⏭️  Pular: {v_title[:45]}... (Já existe)")
                pulos += 1
                continue

        print(f"{prefix} 🎬 Extraindo: {v_title[:45]}...")
        
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run([
                'yt-dlp', '--skip-download', '--write-auto-sub', 
                '--sub-lang', 'pt', '--output', temp_out, v_link
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            vtt_file = f"{temp_out}.pt.vtt"
            if os.path.exists(vtt_file):
                texto = limpar_vtt(vtt_file)
                if len(texto) > 150:
                    with open(caminho_txt, "a", encoding="utf-8") as f:
                        f.write("\n" + "="*60 + "\n")
                        f.write(f"VÍDEO: {v_title}\n")
                        f.write(f"LINK: {v_link}\n")
                        f.write(f"PLAYLIST: {v_playlist_bruta}\n")
                        f.write("-" * 60 + "\n")
                        f.write(f"CONTEÚDO:\n{texto}\n")
                        f.write("="*60 + "\n")
                    
                    nova_linha = {'ID': v_id, 'Link': v_link, 'Titulo': v_title, 'Playlist': v_playlist_bruta, 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False)
                    sucessos += 1
                    print(f"      ✅ Sucesso!")
                else:
                    print(f"      ⚠️  Aviso: Transcrição insuficiente.")
                
                if os.path.exists(vtt_file): os.remove(vtt_file)
            else:
                print(f"      ❌ Erro: YouTube sem legenda.")
            
            time.sleep(3)

        except Exception as e:
            print(f"      ❌ Erro Crítico no arquivo: {e}")

    print(f"\n🏆 FIM DA OPERAÇÃO! Novos: {sucessos} | Pulados: {pulos}")

if __name__ == "__main__":
    minerador_v6_windows_patch()