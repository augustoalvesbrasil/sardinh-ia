import os
import time
import subprocess
import re
import io
import pandas as pd
from datetime import datetime

# Bibliotecas Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload

# ==========================================
# --- CONFIGURAÇÕES DRIVE ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

# --- CONFIGURAÇÕES LOCAIS ---
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
OUTPUT_FOLDER = 'cerebro_local'
GESTÃO_FOLDER = 'gestao_local'
DB_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.xlsx')

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    if not nome: return "Sem_Nome"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str == 'NA': return ""
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    texto_limpo = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
    res = []
    if texto_limpo:
        res.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i].lower() != texto_limpo[i-1].lower(): res.append(texto_limpo[i])
    return " ".join(res).strip()

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- LOGICA DE SINCRONIA INTELIGENTE ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def subir_com_inteligencia(caminho_local, nome_arq, folder_id, service):
    """Sobe como Google Doc se couber, senão sobe como TXT (evita Erro 400)"""
    nome_limpo = nome_arq.replace(".txt", "")
    
    with open(caminho_local, 'r', encoding='utf-8-sig', errors='replace') as f:
        conteudo = f.read()

    # O Google Docs suporta até ~1 milhão de caracteres. Vamos usar 900k como margem.
    tamanho_texto = len(conteudo)
    usar_doc_nativo = tamanho_texto < 900000 
    
    mimetype_final = 'application/vnd.google-apps.document' if usar_doc_nativo else 'text/plain'
    nome_final = nome_limpo if usar_doc_nativo else nome_arq

    # Busca se já existe (checa ambos os nomes possíveis)
    q = f"(name = '{nome_limpo}' or name = '{nome_arq}') and '{folder_id}' in parents and trashed = false"
    res = service.files().list(q=q).execute().get('files', [])

    fh = io.BytesIO(conteudo.encode('utf-8'))
    media = MediaIoBaseUpload(fh, mimetype='text/plain', resumable=True)

    file_metadata = {
        'name': nome_final,
        'mimeType': mimetype_final,
        'parents': [folder_id]
    }

    try:
        if res:
            # Deleta a versão antiga para evitar conflito de formatos
            service.files().delete(fileId=res[0]['id']).execute()
        
        service.files().create(body=file_metadata, media_body=media).execute()
        
        status = "📘 Google Doc" if usar_doc_nativo else "📄 Arquivo TXT (Grande)"
        print(f"   {status}: {nome_final}")
    except Exception as e:
        print(f"   ❌ Erro em {nome_final}: {e}")

def sincronizar_v21_2():
    print("\n☁️  Iniciando Sincronização Inteligente (Docs + TXT Fallback)...")
    try:
        service = get_drive_service()
        for arq in os.listdir(OUTPUT_FOLDER):
            if arq.endswith(".txt"):
                subir_com_inteligencia(os.path.join(OUTPUT_FOLDER, arq), arq, FOLDER_BRAIN_DRIVE, service)
        
        # Planilhas
        for arq_path, nome_drive in [(DB_FILE, 'base_conhecimento_auvp.csv'), (EXCEL_FILE, 'base_conhecimento_auvp.xlsx')]:
            if os.path.exists(arq_path):
                media = MediaFileUpload(arq_path, resumable=True)
                q = f"name = '{nome_drive}' and '{FOLDER_SHEETS_DRIVE}' in parents and trashed = false"
                res = service.files().list(q=q).execute().get('files', [])
                if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
                else: service.files().create(body={'name': nome_drive, 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media).execute()
                print(f"   📊 Planilha: {nome_drive} OK.")
    except Exception as e:
        print(f"❌ Erro Crítico: {e}")

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_engine_v21_2():
    print("\n" + "="*75)
    print("🚀 SARDINHA ENGINE V21.2: THE ARCHITECT (Stable Sync)")
    print("="*75 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER): os.makedirs(OUTPUT_FOLDER)
    if not os.path.exists(GESTÃO_FOLDER): os.makedirs(GESTÃO_FOLDER)

    # 1. Mapeamento
    print("📡 Localizando playlists...")
    stdout_p = executar_comando(['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL])
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines):
            playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    # 2. Varredura
    all_videos = []
    print(f"✅ {len(playlists_info)} Playlists encontradas.")
    for p in playlists_info:
        print(f"   📂 Mapeando: {p['title'][:35]}...")
        stdout_v = executar_comando(['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', f"https://www.youtube.com/playlist?list={p['id']}"])
        for line in stdout_v.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_videos.append({'id': parts[0], 'date': formatar_data(parts[1]), 'views': parts[2], 'title': parts[3], 'playlist': p['title']})

    # 3. Mineração
    total = len(all_videos)
    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    for idx, video in enumerate(all_videos, 1):
        v_id, v_title, v_link = video['id'], video['title'], f"https://www.youtube.com/watch?v={video['id']}"
        nome_txt = f"{sanitizar_nome(video['playlist'])}.txt"
        caminho_local = os.path.join(OUTPUT_FOLDER, nome_txt)
        
        if v_title in ['[Private video]', '[Deleted video]']: continue

        # Check Local
        if os.path.exists(caminho_local):
            with open(caminho_local, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if v_link in f.read():
                    print(f"[{idx}/{total}] ⏭️  Pular: {v_title[:40]}...")
                    continue

        print(f"[{idx}/{total}] 🎬 Extraindo: {v_title[:40]}...")
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            vtt = f"{temp_out}.pt.vtt"
            if os.path.exists(vtt):
                texto = limpar_vtt(vtt)
                if len(texto) > 150:
                    with open(caminho_local, "a", encoding="utf-8-sig") as f:
                        f.write(f"\n{'='*70}\nTITULO: {v_title}\nDATA: {video['date']}\nVIEWS: {video['views']}\nLINK: {v_link}\n{'-'*70}\nCONTEÚDO:\n{texto}\n{'='*70}\n")
                    
                    nova_linha = {'ID': v_id, 'Data_Pub': video['date'], 'Link': v_link, 'Titulo': v_title, 'Playlist': video['playlist'], 'Views': video['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                if os.path.exists(vtt): os.remove(vtt)
            time.sleep(2)
        except Exception as e: print(f"      ❌ Erro: {e}")

    # 4. Excel e Sincronia
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    sincronizar_v21_2()
    print("\n🏆 MISSÃO CUMPRIDA! Todas as playlists estão no Drive.")

if __name__ == "__main__":
    sardinha_engine_v21_2()