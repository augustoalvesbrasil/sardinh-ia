import os
import time
import subprocess
import re
import io
import json
import pandas as pd
from datetime import datetime

# Bibliotecas PDF e Drive
from fpdf import FPDF
from fpdf.enums import XPos, YPos
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload

# ==========================================
# --- CONFIGURAÇÕES ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

# URL que garante TODOS os vídeos do canal (Uploads)
URL_UPLOADS = 'https://www.youtube.com/playlist?list=UUM3vJxmuJJkk1r0yzFI9eZg'

OUTPUT_FOLDER_TXT = 'cerebro_local' 
GESTÃO_FOLDER = 'gestao_local'
DB_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.xlsx')
MAX_WORDS = 400000 

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    if not nome: return "Geral"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    """Converte YYYYMMDD para DD/MM/YYYY"""
    if not data_str or data_str == 'NA': return "Data Indisponível"
    try:
        return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except:
        return str(data_str)

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    texto_limpo = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
    res = []
    if texto_limpo:
        res.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i].lower() != texto_limpo[i-1].lower(): res.append(texto_limpo[i])
    return " ".join(res).strip()

# ==========================================
# --- GERAÇÃO DE PDF ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('helvetica', 'B', 12)
        self.cell(0, 10, 'BASE DE CONHECIMENTO AUVP', border=0, new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        self.ln(5)

def gerar_pdf_em_memoria(lista_blocos):
    pdf = AUVP_PDF()
    pdf.add_page()
    pdf.set_font("helvetica", size=10)
    largura_util = pdf.epw 
    for bloco in lista_blocos:
        msg = bloco.encode('latin-1', 'replace').decode('latin-1')
        if "TITULO:" in msg:
            pdf.set_font('helvetica', 'B', 11)
            pdf.multi_cell(largura_util, 8, msg)
            pdf.set_font('helvetica', size=10)
        else:
            pdf.multi_cell(largura_util, 5, msg)
    return pdf.output()

# ==========================================
# --- DRIVE SYNC ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
        creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def enviar_pdf(service, nome, blocos):
    print(f"   ⬆️ Enviando PDF: {nome}...")
    pdf_bytes = gerar_pdf_em_memoria(blocos)
    fh = io.BytesIO(pdf_bytes)
    media = MediaIoBaseUpload(fh, mimetype='application/pdf', resumable=True)
    q = f"name = '{nome}' and '{FOLDER_BRAIN_DRIVE}' in parents and trashed = false"
    res = service.files().list(q=q).execute().get('files', [])
    if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
    else: service.files().create(body={'name': nome, 'parents': [FOLDER_BRAIN_DRIVE]}, media_body=media).execute()

# ==========================================
# --- MOTOR PRINCIPAL ---
# ==========================================

def sardinha_engine_v30():
    print("\n" + "█"*75)
    print("🚀 SARDINHA ENGINE V30: THE LEVIATHAN (Mapeamento Total)")
    print("█"*75 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER_TXT): os.makedirs(OUTPUT_FOLDER_TXT)
    if not os.path.exists(GESTÃO_FOLDER): os.makedirs(GESTÃO_FOLDER)

    # 1. Mapeamento Total de Vídeos (Lógica Infalível de Dump JSON)
    print("📡 Mapeando todos os vídeos do canal (Pode levar 2-3 minutos)...")
    cmd_full = ['yt-dlp', '--flat-playlist', '--dump-json', '--ignore-errors', URL_UPLOADS]
    result = subprocess.run(cmd_full, capture_output=True, text=True, encoding='utf-8', errors='replace')
    
    all_videos_data = []
    for line in result.stdout.strip().split('\n'):
        try:
            v_data = json.loads(line)
            all_videos_data.append({
                'id': v_data.get('id'),
                'title': v_data.get('title'),
                'date': formatar_data(v_data.get('upload_date')),
                'views': v_data.get('view_count', 0),
                'playlist': 'Geral' # Inicialmente geral, NotebookLM organiza no PDF
            })
        except: continue

    total = len(all_videos_data)
    print(f"✅ {total} vídeos identificados com Data e Views.")

    # Carregar Banco
    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    # 2. Garimpo Local
    for idx, video in enumerate(all_videos_data, 1):
        v_id, v_title, v_date, v_views = video['id'], video['title'], video['date'], video['views']
        v_link = f"https://www.youtube.com/watch?v={v_id}"
        caminho_local_txt = os.path.join(OUTPUT_FOLDER_TXT, "Tutor_AUVP_Completo.txt")
        prefix = f"[{idx}/{total}]"

        if v_title in ['[Private video]', '[Deleted video]']: continue

        # Check local
        if os.path.exists(caminho_local_txt):
            with open(caminho_local_txt, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if v_link in f.read():
                    print(f"{prefix} ⏭️  Pular: {v_title[:45]}")
                    continue

        print(f"{prefix} 🎬 Extraindo: {v_title[:45]}...")
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            vtt = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            if vtt:
                texto = limpar_vtt(vtt[0])
                if len(texto) > 150:
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\nTITULO: {v_title}\nDATA: {v_date}\nVIEWS: {v_views}\nLINK: {v_link}\nCONTEÚDO:\n{texto}\n" + "="*50 + "\n")
                    
                    nova_linha = {'ID': v_id, 'Data_Pub': v_date, 'Link': v_link, 'Titulo': v_title, 'Playlist': 'Geral', 'Views': v_views, 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                    print(f"      ✅ Sucesso!")
                os.remove(vtt[0])
            else: print(f"      ❌ Sem legenda.")
            time.sleep(1) # Rápido no PC local
        except Exception as e: print(f"      ❌ Erro: {e}")

    # 3. Sincronização Final Cloud
    print("\n📊 Atualizando Drive...")
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    
    service = get_drive_service()
    
    # PDF Splitter Inteligente
    with open(caminho_local_txt, 'r', encoding='utf-8-sig', errors='replace') as f:
        videos_lote = f.read().split("="*50)
    
    lote_pdf = []; words = 0; parte = 1
    for v_txt in videos_lote:
        if not v_txt.strip(): continue
        w_count = len(v_txt.split())
        if words + w_count > MAX_WORDS:
            enviar_pdf(service, f"Tutor_AUVP_Parte_{parte}.pdf", lote_pdf)
            lote_pdf = [v_txt]; words = w_count; parte += 1
        else:
            lote_pdf.append(v_txt + "\n" + "="*50)
            words += w_count
    if lote_pdf:
        enviar_pdf(service, f"Tutor_AUVP_Parte_{parte}.pdf", lote_pdf)

    # Planilhas
    for path, nome in [(DB_FILE, 'base_conhecimento_auvp.csv'), (EXCEL_FILE, 'base_conhecimento_auvp.xlsx')]:
        media = MediaFileUpload(path, resumable=True)
        q = f"name = '{nome}' and '{FOLDER_SHEETS_DRIVE}' in parents and trashed = false"
        res = service.files().list(q=q).execute().get('files', [])
        if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
        else: service.files().create(body={'name': nome, 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media).execute()

    print(f"\n🏆 DRIVE E PC ATUALIZADOS! {total} vídeos processados.")

if __name__ == "__main__":
    sardinha_engine_v30()