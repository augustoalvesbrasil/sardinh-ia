import os
import time
import subprocess
import re
import io
import pandas as pd
from datetime import datetime
from fpdf import FPDF
from fpdf.enums import XPos, YPos

# Bibliotecas Google Drive
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# ==========================================
# --- CONFIGURAÇÕES DRIVE ---
# ==========================================
FOLDER_BRAIN_DRIVE = '17AbJyV-ckWJFEngdsNytMBAxX_AIKQE2'   
FOLDER_SHEETS_DRIVE = '1CPrBStkj77nNzS8olKiz7mtDBVZ79pJK'  
SCOPES = ['https://www.googleapis.com/auth/drive']

# --- CONFIGURAÇÕES LOCAIS (BASEADO NA V4) ---
URL_CANAL = 'https://www.youtube.com/@InvestidorSardinha/playlists'
OUTPUT_FOLDER_TXT = 'cerebro_local' 
GESTÃO_FOLDER = 'gestao_local'
DB_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.csv')
EXCEL_FILE = os.path.join(GESTÃO_FOLDER, 'base_conhecimento_auvp.xlsx')

# Limite de palavras para o NotebookLM (Segurança: 400k)
MAX_WORDS = 400000

# ==========================================
# --- UTILITÁRIOS ---
# ==========================================

def sanitizar_nome(nome):
    if not nome: return "Sem_Nome"
    return re.sub(r'[<>:"/\\|?*]', '', str(nome)).strip()

def formatar_data(data_str):
    if not data_str or data_str in ['NA', 'None']: return "Data Indisponível"
    try: return datetime.strptime(str(data_str), '%Y%m%d').strftime('%d/%m/%Y')
    except: return data_str

def limpar_vtt(caminho_vtt):
    if not os.path.exists(caminho_vtt): return ""
    with open(caminho_vtt, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    texto_limpo = [re.sub(r'<[^>]*>', '', l.strip()) for l in linhas if '-->' not in l and not l.strip().isdigit() and 'WEBVTT' not in l]
    res = []
    if texto_limpo:
        res.append(texto_limpo[0])
        for i in range(1, len(texto_limpo)):
            if texto_limpo[i].lower() != texto_limpo[i-1].lower(): res.append(texto_limpo[i])
    return " ".join(res).strip()

def executar_comando(cmd):
    result = subprocess.run(cmd, capture_output=True, text=False, check=False)
    return result.stdout.decode('utf-8', errors='replace')

# ==========================================
# --- LIBRARIAN: GERAÇÃO DE PDF RESILIENTE ---
# ==========================================

class AUVP_PDF(FPDF):
    def header(self):
        self.set_font('helvetica', 'B', 12)
        self.cell(0, 10, 'BASE DE CONHECIMENTO AUVP', border=0, 
                  new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
        self.ln(5)

def criar_pdf_seguro(nome_arquivo, lista_blocos):
    """Gera um PDF tratando erros de espaço e caracteres"""
    print(f"   📑 Gerando: {nome_arquivo}...")
    pdf = AUVP_PDF()
    pdf.add_page()
    pdf.set_font("helvetica", size=10)
    
    # epw = Effective Page Width (evita o erro de horizontal space)
    largura_util = pdf.epw 

    for bloco in lista_blocos:
        # Sanitização final para latin-1 (formato interno do FPDF básico)
        msg = bloco.encode('latin-1', 'replace').decode('latin-1')
        
        if "TITULO:" in msg:
            pdf.set_font("helvetica", 'B', 11)
            pdf.multi_cell(largura_util, 8, msg)
            pdf.set_font("helvetica", size=10)
        else:
            pdf.multi_cell(largura_util, 5, msg)
            
    pdf.output(nome_arquivo)
    return nome_arquivo

# ==========================================
# --- LOGICA DE SINCRONIA ---
# ==========================================

def get_drive_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
        creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token: token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def sincronizar_e_particionar():
    print("\n☁️  Iniciando Particionamento e Upload para Drive...")
    service = get_drive_service()
    
    for arq_txt in os.listdir(OUTPUT_FOLDER_TXT):
        if arq_txt.endswith(".txt"):
            caminho_txt = os.path.join(OUTPUT_FOLDER_TXT, arq_txt)
            nome_base = arq_txt.replace(".txt", "")
            
            with open(caminho_txt, 'r', encoding='utf-8-sig', errors='replace') as f:
                conteudo_bruto = f.read()
            
            # Divide o arquivo por vídeos (usando o separador v4)
            blocos_videos = conteudo_bruto.split("="*50)
            
            batches_pdf = []
            lote_atual = []
            contagem_palavras = 0
            parte = 1

            for bloco in blocos_videos:
                if not bloco.strip(): continue
                
                palavras_bloco = len(bloco.split())
                
                # Se o lote atual vai estourar o limite do Google
                if contagem_palavras + palavras_bloco > MAX_WORDS:
                    nome_parte = f"{nome_base} - Parte {parte}.pdf"
                    batches_pdf.append(criar_pdf_seguro(nome_parte, lote_atual))
                    lote_atual = [bloco]
                    contagem_palavras = palavras_bloco
                    parte += 1
                else:
                    lote_atual.append(bloco + "\n" + "="*50)
                    contagem_palavras += palavras_palavras_bloco = len(bloco.split())
                    contagem_palavras += palavras_bloco

            # Salva o resto do conteúdo
            if lote_atual:
                nome_f = f"{nome_base} - Parte {parte}.pdf" if parte > 1 else f"{nome_base}.pdf"
                batches_pdf.append(criar_pdf_seguro(nome_f, lote_atual))

            # Upload de cada PDF gerado
            for pdf_file in batches_pdf:
                media = MediaFileUpload(pdf_file, mimetype='application/pdf', resumable=True)
                q = f"name = '{pdf_file}' and '{FOLDER_BRAIN_DRIVE}' in parents and trashed = false"
                res = service.files().list(q=q).execute().get('files', [])
                
                if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
                else: service.files().create(body={'name': pdf_file, 'parents': [FOLDER_BRAIN_DRIVE]}, media_body=media).execute()
                
                print(f"      ✅ Sincronizado no Drive: {pdf_file}")
                if os.path.exists(pdf_file): os.remove(pdf_file)

    # Planilhas
    for path, nome in [(DB_FILE, 'base_conhecimento_auvp.csv'), (EXCEL_FILE, 'base_conhecimento_auvp.xlsx')]:
        if os.path.exists(path):
            media = MediaFileUpload(path, resumable=True)
            q = f"name = '{nome}' and '{FOLDER_SHEETS_DRIVE}' in parents and trashed = false"
            res = service.files().list(q=q).execute().get('files', [])
            if res: service.files().update(fileId=res[0]['id'], media_body=media).execute()
            else: service.files().create(body={'name': nome, 'parents': [FOLDER_SHEETS_DRIVE]}, media_body=media).execute()
            print(f"   📊 Planilha Sincronizada: {nome}")

# ==========================================
# --- MOTOR PRINCIPAL (V4 CORE) ---
# ==========================================

def sardinha_engine_v26():
    print("\n" + "█"*75)
    print("🚀 SARDINHA ENGINE V26: THE INDUSTRIAL SPLITTER")
    print("█"*75 + "\n")
    
    if not os.path.exists(OUTPUT_FOLDER_TXT): os.makedirs(OUTPUT_FOLDER_TXT)
    if not os.path.exists(GESTÃO_FOLDER): os.makedirs(GESTÃO_FOLDER)

    # 1. Mapeamento
    print("📡 Escaneando canal no YouTube...")
    stdout_p = executar_comando(['yt-dlp', '--flat-playlist', '--get-id', '--get-title', '--ignore-errors', URL_CANAL])
    p_lines = [l.strip() for l in stdout_p.split('\n') if l.strip()]
    playlists_info = []
    for i in range(0, len(p_lines), 2):
        if i+1 < len(p_lines): playlists_info.append({'title': p_lines[i], 'id': p_lines[i+1]})

    # 2. Varredura Total
    all_videos = []
    print(f"✅ {len(playlists_info)} Playlists encontradas.")
    for p in playlists_info:
        print(f"   📂 Mapeando: {p['title'][:35]}...")
        stdout_v = executar_comando(['yt-dlp', '--flat-playlist', '--ignore-errors', '--print', '%(id)s|||%(upload_date)s|||%(view_count)s|||%(title)s', f"https://www.youtube.com/playlist?list={p['id']}"])
        for line in stdout_v.split('\n'):
            parts = line.split('|||')
            if len(parts) >= 4:
                all_videos.append({'id': parts[0], 'date': formatar_data(parts[1]), 'views': parts[2], 'title': parts[3], 'playlist': p['title']})

    # 3. Mineração Local (v4 Robustness)
    total = len(all_videos)
    df_db = pd.read_csv(DB_FILE, dtype=str) if os.path.exists(DB_FILE) else pd.DataFrame(columns=['ID', 'Data_Pub', 'Link', 'Titulo', 'Playlist', 'Views', 'Status'])

    for idx, video in enumerate(all_videos, 1):
        v_id, v_title, v_date = video['id'], video['title'], video['date']
        v_link = f"https://www.youtube.com/watch?v={v_id}"
        nome_txt = f"{sanitizar_nome(video['playlist'])}.txt"
        caminho_local_txt = os.path.join(OUTPUT_FOLDER_TXT, nome_txt)
        prefix = f"[{idx}/{total}]"

        if v_title in ['[Private video]', '[Deleted video]']: continue

        if os.path.exists(caminho_local_txt):
            with open(caminho_local_txt, 'r', encoding='utf-8-sig', errors='ignore') as f:
                if v_link in f.read():
                    print(f"{prefix} ⏭️  Pular: {v_title[:45]}...")
                    continue

        print(f"{prefix} 🎬 Extraindo: {v_title[:45]}...")
        try:
            temp_out = f"temp_{v_id}"
            subprocess.run(['yt-dlp', '--skip-download', '--write-auto-sub', '--sub-lang', 'pt', '--output', temp_out, v_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            vtt_files = [f for f in os.listdir('.') if f.startswith(temp_out) and f.endswith('.vtt')]
            if vtt_files:
                texto = limpar_vtt(vtt_files[0])
                if len(texto) > 150:
                    with open(caminho_local_txt, "a", encoding="utf-8-sig") as f:
                        f.write(f"\nTITULO: {v_title}\nDATA: {v_date}\nVIEWS: {video['views']}\nLINK: {v_link}\nCONTEÚDO:\n{texto}\n" + "="*50 + "\n")
                    nova_linha = {'ID': v_id, 'Data_Pub': v_date, 'Link': v_link, 'Titulo': v_title, 'Playlist': video['playlist'], 'Views': video['views'], 'Status': 'Sucesso'}
                    df_db = pd.concat([df_db, pd.DataFrame([nova_linha])], ignore_index=True)
                    df_db.to_csv(DB_FILE, index=False, encoding='utf-8-sig')
                    print(f"      ✅ Sucesso!")
                for f in vtt_files: os.remove(f)
            else:
                print(f"      ❌ Sem legenda.")
            time.sleep(2)
        except Exception as e: print(f"      ❌ Erro: {e}")

    # 4. Finalização
    df_db['Views'] = pd.to_numeric(df_db['Views'], errors='coerce').fillna(0).astype(int)
    df_db.to_excel(EXCEL_FILE, index=False)
    sincronizar_e_particionar()
    print(f"\n🏆 DRIVE ATUALIZADO! PDFs divididos para o NotebookLM.")

if __name__ == "__main__":
    sardinha_engine_v26()